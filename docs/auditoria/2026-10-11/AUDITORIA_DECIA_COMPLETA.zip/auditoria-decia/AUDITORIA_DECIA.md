# Auditoria crítica do DECIA

**UX/UI, maturidade funcional e plano para alcançar 10 · 11 de outubro de 2026**

Repositório: `MatheusHaliski/Decia-app-2026`, branch `main`, commit `1932b73dca3a422e58547ecc592c0542d42e3a38`.

O DECIA tem uma base visual e um modelo decisório superiores ao que seria esperado de um simples esqueleto: cards com estados, comparação por critérios, sensibilidade, evidências separadas de premissas, responsável humano e trilha de decisão. A experiência atual ainda é uma demonstração: o núcleo decisório e a rede social guardam dados na memória da aba, diversas telas mostram especificações de requisitos e a colaboração real ainda não está conectada. A prioridade é transformar a decisão demonstrada em um registro persistente, seguro e compreensível.

**Nota global heurística: 5,5/10.** Isso avalia o produto demonstrado e sua prontidão funcional, não apenas a aparência. A nota de interface decisória é **7,5/10**; a de confiabilidade funcional ponta a ponta é **3/10**. Uma boa demonstração não prova que o produto já suporta decisões institucionais reais.

## 1. Como foi verificado

- Inspeção de `app/`, `components/`, `lib/`, tokens, repositórios DEMO, controllers Java, manifests, CI e documentação de arquitetura/produto.
- Build de produção do Next.js 15.5.27, Chromium via Playwright; 12 destinos × 3 viewports = **36 visitas e 36 capturas**.
- Viewports: celular 390×844 com toque; tablet 820×1180; desktop 1440×900. Tema claro, idioma pt-BR, densidade padrão.
- Medições: h1 e tamanho, texto abaixo de 12 px, largura/estouro horizontal, CLS, LCP, long tasks, controles e dimensões, erros JavaScript e respostas HTTP. Dados brutos em `medicoes.json`; script em `medir.cjs`.
- Navegação protegida habilitada por cookies **simulados** da suíte existente. Isso permite examinar a interface DEMO; não equivale a autenticação real nem valida permissões no servidor.
- O exemplo FashionAI foi usado como referência de organização: diagnóstico, tabela por fluxo, notas, plano, propostas e métricas. Suas observações e números não foram transferidos para o DECIA.

**Limites:** uma passagem por destino/viewport, sem limitação de CPU/rede, sem dispositivos físicos, sem leitores de tela, sem axe-core e sem entrevistas. As medidas de carregamento local não representam usuários reais. Não foram medidos INP de campo, retenção, taxa de sucesso de usuários nem qualidade de IA remota. As notas são julgamento heurístico; não são certificação de WCAG, segurança ou LGPD. A captura de cada página completa documenta seu conteúdo, mas não comprova que cada ação foi executada.

A auditoria anterior em `docs/decia/01_AUDITORIA.md`, datada de 06/10, descrevia ausência de cards e workspace. Essa conclusão ficou desatualizada: os componentes atuais existem e seus fluxos de demonstração foram exercitados. O documento anterior permanece como histórico; esta avaliação usa o commit acima.

### Achados técnicos confirmados na revisão do mesmo baseline

Foram confirmados dois problemas adicionais de autenticação: as propriedades das chaves JWT não eram vinculadas corretamente ao record com construtor sobrecarregado, tornando a emissão indisponível mesmo com configuração presente; e os formulários sem `method` explícito usavam GET no envio nativo, podendo colocar senha/código na URL quando a hidratação não ocorria. As correções posteriores têm testes de regressão e estão em `VALIDACAO.md`. As notas abaixo descrevem o cenário inicial e permanecem heurísticas.

## 2. Diagnóstico geral

### O que já funciona bem

**A decisão é uma unidade visível.** A caixa “Precisa de atenção” separa o que aguarda decisão, precisa de evidência e requer revisão. O workspace deixa a pergunta e o responsável em primeiro plano. Isso aproxima o produto do trabalho real, em vez de organizar tudo apenas como conversas.

**A explicação tem estrutura.** Critérios, pesos, alternativas, prós/contras e sensibilidade mostram como a recomendação é construída. Alterar o peso de Custo de 20 para 25 produz o aviso de soma de 105%, verificado pela suíte E2E. A recomendação do modelo é distinguível da escolha humana.

**O design system tem fundamentos sólidos.** Há tokens de cor, tipografia, espaçamento, camadas, movimento e controles; primitivos com Radix; preferência de movimento reduzido; i18n em pt-BR/en/es. O shell agrupa a navegação e usa glifos distintos. Os títulos principais medidos têm 24 px.

**Existe disciplina técnica verificável.** Há testes de regras, contratos e componentes; CI declara build, análise estática, cobertura, testes de integração e verificações de segurança. A presença de um job não prova sua execução no GitHub; os resultados locais estão registrados no anexo de validação.

### O que impede nota 10

1. **Persistência e colaboração:** decisões e interações são DEMO em memória. Recarregar volta aos exemplos; não há evidência de uma API de decisão funcionando entre duas pessoas.
2. **Linguagem de especificação na interface:** códigos RF/CA, nomes de classes, notas de matriz e texto de README aparecem nas telas. A documentação ocupa espaço que deveria ajudar a concluir uma tarefa.
3. **Estabilidade visual:** CLS observado acima de 0,1 em várias visitas de tablet e desktop. É necessário localizar as mudanças na hidratação e reservar o espaço final do conteúdo.
4. **Legibilidade:** cerca de 20% a 23% dos nós de texto contados ficaram abaixo de 12 px. Chips, metadados e rótulos técnicos acumulam sinais pequenos.
5. **Promessa maior que a entrega:** Sessões e outras abas ainda mostram estados de esqueleto; sugestões de IA indicam serviço não conectado; perfis de visualização vêm de dados locais de laboratório.
6. **Resultados reais ausentes:** não há evidência nesta auditoria de ativação, redução do tempo de decisão, aprendizagem pós-resultado ou adoção pelos servidores públicos.

## 3. Medições do cenário atual

| Medida | Celular | Tablet | Desktop | Interpretação |
|---|---:|---:|---:|---|
| Visitas | 12 | 12 | 12 | Amostra de destinos; não cobertura integral do produto |
| Estouro horizontal | 0/12 | 0/12 | 0/12 | Nenhum observado na configuração auditada |
| CLS mediano observado | 0,000 | 0,199 | 0,143 | Tablet/desktop ultrapassam a referência de bom ≤0,1 |
| LCP mediano local | 266 ms | 266 ms | 508 ms | Ambiente local; não usar como promessa de performance |
| Texto <12 px | 366/1.603 (22,8%) | 380/1.716 (22,1%) | 390/1.991 (19,6%) | Contagem de elementos com texto direto, não palavras nem usuários |
| Controles com uma dimensão <44 px, mediana por destino | 14 | 18,5 | 45,5 | Triagem geométrica; não equivale a violação WCAG |
| Erros JavaScript não tratados | 0 | 0 | 0 | Nas visitas medidas |

Exemplos de CLS no desktop: `/decia` **0,412**; quadro de decisões **0,377**; workspace da arquitetura **0,527**; preferências **0,646**. Esses valores são de uma execução, não percentis de produção. A causa exata de cada deslocamento exige inspeção de fontes de layout e repetição controlada; componentes que trocam loading por conteúdo são candidatos, não causa comprovada.

**Cuidados de interpretação:** os auxiliares invisíveis de formulário do Radix (`aria-hidden`, `tabindex=-1`, opacidade zero) apareceram na triagem de controles sem nome. Eles não devem ser tratados como defeito de nome acessível; os controles interativos precisam ser avaliados separadamente. A medida geométrica também inclui links de texto e não verifica exceções/espaçamento da WCAG 2.2. 44 px é aqui uma meta de conforto no toque; o critério AA de tamanho mínimo é 24 CSS px, com exceções.

Ocorreram respostas **502 em `/bff/auth/refresh`** com sessão fictícia e backend indisponível durante as capturas. São evidência do cenário de laboratório, não prova de falha da autenticação real. Login e cadastro não apresentaram h1 no DOM, embora possuam título visual. Não foi medido contraste numérico nesta auditoria.

## 4. Tabela por tela ou fluxo

Prioridades: **P0** bloqueia piloto com dados reais; **P1** afeta fluxo principal; **P2** melhora qualidade e escala. “Observado” significa navegador/captura; “código” significa inspeção estática; “não validado” delimita uma capacidade ainda não comprovada.

| ID | Tela/fluxo | Achado e evidência | Impacto | Prioridade | Correção e critério de aceite |
|---|---|---|---|---|---|
| F1 | DECIA e social | `lib/decia/repository.ts` e `lib/social/repository.ts`: memória da aba, origem DEMO | Decisão e trabalho desaparecem ao recarregar | P0 | API persistente; criar, recarregar e abrir em outro navegador preserva dados e versão |
| F2 | Permissões | `ViewerProvider` usa perfil de laboratório/localStorage; workspace usa usuário DEMO | Visibilidade da UI não comprova autorização | P0 | Identidade real; BOLA/BFLA por organização, participação e recurso no servidor; testes negativos |
| F3 | Colaboração | Nenhuma API de decisão nos controllers atuais; contratos de repositório preparados | Não prova deliberação entre pessoas | P0 | Dois usuários reais contribuem; isolamento entre organizações e conflito de versão testados |
| G1 | Páginas do shell | `RfPage`, `PageHeader`: RF/CA, matriz, arquivo e README expostos; captura desktop-06 | Usuário precisa interpretar linguagem de implementação | P1 | Mover rastreio para laboratório/docs; validar que a interface normal não mostra códigos ou nomes de classes |
| G2 | Layout/hidratação | CLS >0,1 em visitas do shell, quadro e workspace | Conteúdo muda de posição e pode induzir clique errado | P1 | Reservar altura/largura dos estados iniciais; CLS p75≤0,1 em campo, repetição local como gate provisório |
| G3 | Legibilidade | 19,6–22,8% dos nós <12 px; chips e notas nas capturas | Leitura lenta e fadiga | P1 | Corpo 14–16 px, rótulos secundários normalmente ≥12 px; revisar escala 200% e contraste |
| G4 | Navegação | Sidebar já agrupada, mas muitos destinos e rótulos extensos; observado | Carga de escolha no primeiro uso | P2 | Destinos por frequência e papel; busca com linguagem de tarefa; medir tempo para encontrar função |
| D1 | Card de decisão | Estado, confiança, risco, impacto, evidência, responsável e prazo coexistem | Usuário precisa distinguir sinais e sua origem | P1 | Manter pergunta, estado, próxima ação e dono/prazo; detalhes no verso; compreensão em ≤10 s |
| D2 | Recomendação | `Analysis`, `CriteriaMatrix`, regras de sensibilidade; pontuação numérica nos cards | Pode sugerir precisão maior que a evidência disponível | P1 | Mostrar escala, limitações, qualidade da evidência e condições que alteram a liderança |
| D3 | Workspace | 9 estágios + seções + prontidão + saúde; captura celular-08 | Profundidade útil, porém extensa no celular | P1 | Próxima ação no topo; edição progressiva; manter contexto ao trocar seção e retornar |
| D4 | Snapshot/rastro | `commands.ts` produz snapshot/hash e eventos no agregado DEMO | Hash local não prova histórico imutável de produção | P0 | Persistência append-only, autorização e validação de integridade; adulteração e concorrência rejeitadas |
| D5 | Sessões | `SessionsTab` apresenta EmptyState e nota de especificação | Estado vazio mistura falta de dados com falta de implementação | P1 | Diferenciar “nenhuma sessão” de “recurso ainda indisponível”; não prometer ação inexistente |
| D6 | Revisões | Vista presente e exemplo de checkpoint; execução real não validada | Aprendizado continua dependente do exemplo | P1 | Agendamento, responsável, resultado e retrospectiva persistidos; lembretes idempotentes |
| I1 | IA | `decia.challenge.notConnected`: serviço ainda não conectado | O nome DECIA cria expectativa de assistência real | P1 | Explicar disponibilidade; conectar somente com proveniência, aceite humano, avaliação e limites de dados |
| S1 | Mural/mensagens | Social DEMO; mensagens/abas ainda contêm especificação e estados provisórios | Sensação de produto completo sem colaboração real | P1 | Diferenciar DEMO e produção; concluir uma jornada prioritária antes de expandir catálogo |
| A1 | Login/cadastro | Título visual sem h1; texto “24 h (Q-30)” e referências RF | Estrutura semântica e linguagem de entrada inconsistentes | P2 | Um h1 por tela; linguagem simples; validar erros, autofill e teclado |
| A2 | Toque e teclado | Vários controles <44 px; flip por teclado passou no E2E DECIA | Base acessível existente, auditoria completa pendente | P1 | Alvos confortáveis, foco visível, ordem lógica, Escape e retorno de foco; axe + leitor de tela |
| O1 | Dados institucionais | Segurança e LGPD documentadas; operação real não auditada | Sigilo e responsabilidade exigem evidência além de UI | P0 | Testar isolamento, trilha sem segredos, retenção, exportação, restauração e políticas de IA |

O fundo creme, os glifos clay e os tokens formam identidade própria. Não há evidência suficiente para recomendar abandonar essa identidade. A correção deve diminuir ruído e melhorar hierarquia, preservando a linguagem visual.

## 5. Notas heurísticas de 0 a 10

Escala: 0–2 = ausente/não demonstrado; 3–4 = parcial; 5–6 = demonstração utilizável com lacunas; 7–8 = consistente no escopo validado; 9 = experiência completa com validação ampla; 10 = todos os critérios de excelência acordados atendidos e sustentados por evidências. Dez não significa ausência eterna de defeitos.

| Dimensão | Atual | Peso | Por que recebeu esta nota | O que falta para 10 |
|---|---:|---:|---|---|
| Identidade e coerência visual | 7,0 | 10% | Tokens, marca e glifos consistentes; ruído de badges e documentação | Hierarquia refinada, temas e estados auditados, coerência comprovada entre fluxos |
| Navegação e arquitetura de informação | 6,0 | 10% | Grupos e busca existem; amplitude alta e onboarding não validado | Usuários encontram funções e próxima ação sem ajuda |
| Clareza, conteúdo e legibilidade | 5,0 | 10% | Textos técnicos e muitos rótulos pequenos | Linguagem de trabalho, tipografia legível, distinção clara de DEMO e indisponível |
| UX da decisão e explicabilidade | 7,5 | 15% | Pergunta, evidência, critérios, sensibilidade e dono visíveis | Jornada real completa; compreensão e qualidade decisória avaliadas com usuários |
| Acessibilidade e adaptação | 6,5 | 10% | Sem overflow; Radix e flip acessível; faltam auditoria AA e testes assistivos | WCAG 2.2 AA no escopo, teclado/leitor de tela e zoom validados |
| Performance e estabilidade | 5,0 | 10% | LCP local baixo, mas CLS elevado; sem INP/RUM | LCP≤2,5 s, INP≤200 ms, CLS≤0,1 no p75 real, por dispositivo |
| Engenharia e capacidade de validação | 8,0 | 10% | Tipagem, testes, contratos e gates verificáveis | CI real obrigatório, testes de fluxos persistentes, operação e regressão documentadas |
| Confiabilidade funcional e persistência | 3,0 | 15% | Núcleo DECIA/social em memória; API de identidade separada | Dados duráveis, concorrência, recuperação, autorização e jornada ponta a ponta |
| Colaboração e execução institucional | 2,0 | 5% | Modelo e UI preparados; colaboração real não demonstrada | Dois usuários reais, conflitos, notificações, execução e revisão funcionando |
| IA, governança e aprendizado | 2,0 | 5% | Origem/aceite humano previstos; serviço não conectado | Avaliação de qualidade, proveniência, privacidade, custo e loop de aprendizado |

**Cálculo:** soma de nota × peso = **5,525**, arredondada para **5,5/10**. A média não deve compensar um bloqueador P0: persistência, autorização e integridade são condições obrigatórias para piloto com dados reais, mesmo que a nota visual suba.

## 6. Plano para alcançar 10

As durações são estimativas iniciais para uma equipe com produto/design, frontend e backend, com apoio de QA/segurança. Não são compromisso de calendário; dependem da conclusão dos requisitos de segurança e do escopo escolhido.

| Etapa | Horizonte indicativo | Entregas | Responsável principal | Condição para avançar |
|---|---|---|---|---|
| 0 · Base e recorte | 2–3 dias | Fixar commit, inventariar DEMO/real, selecionar jornada “criar → comparar → decidir → revisar”, matriz de evidências e riscos | Produto + tech lead | Critérios de aceite e dados permitidos definidos; validação técnica reproduzível |
| 1 · Clareza e estabilidade | 3–5 dias | G1–G3, D1, A1; reservar layout, simplificar cards, remover jargão da interface normal | Design + frontend | Zero jargão técnico no caminho principal; melhoria de CLS comprovada; leitura com 200% |
| 2 · Núcleo persistente e seguro | 2–4 semanas | F1–F3, D4, O1; casos de uso/API, identidade real, versão otimista, snapshot e trilha | Backend + segurança | Recarregar e segundo navegador preservam dados; BOLA/BFLA e adulteração bloqueadas |
| 3 · Colaboração e execução | 2–3 semanas após etapa 2 | Sessões/contribuições, avaliação independente, notificações, tarefas e checkpoints persistidos | Backend + frontend | Dois participantes reais concluem e revisam decisão; falhas e conflitos têm recuperação |
| 4 · IA controlada e aprendizado | 2–3 semanas, depois de governança | Assistente com proveniência, desafio de premissas, aceite/rejeição, avaliação e retrospectiva | IA + produto + segurança | Conjunto de avaliação aprovado; sem decisão automática; dados sigilosos respeitam política |
| 5 · Piloto e excelência | 2–4 semanas | Pesquisa com 5–8 usuários por rodada, testes assistivos, RUM, restauração e revisão de métricas | Produto + QA + operação | Todos os critérios abaixo atendidos por duas releases consecutivas |

### Correções rápidas

- Tirar os blocos de README/RF/CA da experiência normal e manter rastreabilidade em docs/laboratório.
- Trocar “o que esta aba vai fazer” por explicação operacional ou aviso honesto de indisponibilidade.
- Revisar rótulos abaixo de 12 px, títulos sem h1 e textos Q-30/RF na entrada.
- Expor no DEMO: “Dados de exemplo. Alterações são perdidas ao recarregar.” O selo atual é positivo, mas o efeito precisa ser evidente.
- Reservar espaço dos estados loading e identificar fontes reais de CLS antes de corrigir.
- Diferenciar “modelo recomenda”, “humano decidiu” e “IA sugeriu” por texto e origem, não só cor.

### Critérios objetivos de nota 10

1. **Jornada real:** criar decisão, registrar evidência/premissa, comparar, decidir, ligar execução e revisar com dados persistidos. Repetir após reload, outro navegador e reinício de serviço.
2. **Segurança:** isolamento entre organizações e por recurso; papéis reais; testes negativos de acesso; nenhum segredo/conteúdo sensível indevido em logs. Revisão técnica independente antes do piloto institucional.
3. **Histórico:** snapshot imutável com integridade validada, trilha de autoria e versão, política de retenção e restauração ensaiada. Um hash isolado não basta.
4. **Usabilidade:** pelo menos 90% de sucesso sem ajuda nas tarefas prioritárias nas rodadas de validação; pergunta, dono e próxima ação identificados em ≤10 s; justificativa e sensibilidade compreendidas. Amostras pequenas dão sinal, não estimativa estatística de toda a população.
5. **Acessibilidade:** auditoria WCAG 2.2 AA; nenhum achado crítico/sério automatizado sem tratamento; navegação completa por teclado, leitor de tela, zoom 200% e movimento reduzido. Teste automático não substitui revisão manual.
6. **Performance:** p75 real de LCP≤2,5 s, INP≤200 ms, CLS≤0,1, segmentado por dispositivo e fluxo, com volume de amostra suficiente. Enquanto houver pouco tráfego, usar perfil de laboratório padronizado e publicar essa limitação.
7. **Colaboração:** contribuições independentes, permissão de cada participante, concorrência sem perda silenciosa e estados de erro compreensíveis. Notificações não duplicam nem expõem conteúdo restrito.
8. **IA:** respostas vinculadas a fontes/autoria/versão, limites de uso e custo, avaliação de alucinação e fundamentação, aceite humano explícito e nenhuma promoção automática de hipótese a fato.
9. **Operação:** CI bloqueante, alertas úteis, rollback e restauração testados, observabilidade de falhas da jornada, runbook e responsáveis.
10. **Evidência continuada:** repetir avaliação depois das mudanças e sustentar os critérios por duas releases. Recalcular notas por dimensão; não atribuir 10 apenas porque os tickets foram fechados.

## 7. Redesign dos três pontos de maior impacto

Propostas para implementação futura; nenhuma mudança de produto foi aplicada nesta auditoria.

### 7.1 Caixa de atenção e card decisório

No topo, mostrar “O que precisa de você hoje”, com contagem e uma ação principal. O card responde em sequência: **qual pergunta**, **qual estado**, **o que fazer agora**, **quem responde e até quando**. Risco, confiança e evidência ficam em uma linha secundária ou no verso. Em vez de uma nota com aparência de certeza, mostrar “Lidera pelos critérios atuais” e permitir abrir escala e sensibilidade. Exemplos DEMO permanecem explicitamente marcados.

Preservar frente/verso e acesso por teclado. O botão deve indicar que abre a justificativa; a explicação não pode depender de descobrir o atalho F. Testar leitura em dez segundos e em celular com fonte ampliada.

### 7.2 Workspace com aprofundamento progressivo

Manter uma faixa compacta com pergunta, responsável, estado e próxima ação. Em celular, abrir a seção necessária em vez de apresentar todo o relatório antes da edição. O caminho é “Enquadrar → Comparar → Decidir → Acompanhar”, mantendo evidências, hipóteses e riscos disponíveis como aprofundamento. Não é necessário apagar os nove estágios do modelo: eles podem orientar o progresso sem competir com a navegação.

Antes de decidir, resumir bloqueios e avisos em linguagem concreta: “Falta confirmar a premissa de capacidade” em vez de apenas um índice de saúde. A confirmação registra justificativa e confiança sem transmitir que a IA está autorizando a decisão.

### 7.3 Entrada e primeiro uso

Depois da autenticação real, oferecer três passos: “Crie uma pergunta”, “Compare pelo menos duas alternativas”, “Defina responsável e revisão”. Separar a visita ao exemplo da criação de dado real. Reduzir texto de especificação no cadastro/login; manter transparência sobre dados e proteção de conta. Se um recurso ainda não existir, explicar isso antes do clique, com alternativa útil.

## 8. Métricas para acompanhar

Não há números de uso reais nesta auditoria. Instrumentar uma linha de base antes de usar estas metas para afirmar melhoria. Em ambiente institucional, coletar o mínimo necessário e evitar registrar texto de decisões, evidências ou mensagens nos eventos analíticos.

| Métrica | Definição | Coleta | Meta de trabalho |
|---|---|---|---|
| Ativação | Novos usuários com primeira decisão persistida e responsável definido em 7 dias | Eventos mínimos + banco | Definir depois da linha de base; não inventar percentual atual |
| Sucesso por tarefa | Tarefas prioritárias concluídas sem ajuda / tentativas | Teste moderado + eventos de conclusão | ≥90% no escopo validado |
| Tempo para próxima ação | Tempo até identificar o próximo passo correto | Roteiro de usabilidade | ≤10 s para leitura do card |
| Persistência confiável | Decisões recuperadas após reload/reinício / amostra criada | E2E real e teste de restauração | 100% da amostra de aceite |
| Integridade do histórico | Tentativas de alterar snapshot/evento rejeitadas | Testes de API/banco | Todas as tentativas previstas rejeitadas |
| Revisão no prazo | Checkpoints revistos no prazo / devidos | Agenda persistida | Estabelecer meta com área usuária |
| Evidência e premissas | Decisões com fonte rastreável e premissas críticas tratadas | Dados estruturados; sem pontuar volume de texto | Monitorar qualidade, não estimular burocracia |
| Performance | LCP, INP, CLS no p75 por dispositivo | RUM com minimização de dados | ≤2,5 s / ≤200 ms / ≤0,1 |
| Acessibilidade | Achados por gravidade + tarefas assistivas concluídas | axe + teclado/leitor/zoom | Zero pendência bloqueante; AA no escopo |
| Qualidade de IA | Fundamentação, erro factual, utilidade, abstinência apropriada | Conjunto de avaliação + revisão humana | Metas aprovadas por caso de uso antes da liberação |
| Operação | Falhas de jornada, latência de API, recuperação | Logs/metrics sem conteúdo sensível | SLOs definidos com operação e área usuária |

Não usar pontos, quantidade de argumentos ou adesão à recomendação da IA como prova de qualidade da decisão. Resultado e qualidade do processo devem ser avaliados separadamente; uma decisão bem fundamentada pode ter resultado ruim por incerteza.

## 9. As 36 perguntas, adaptadas ao DECIA

### Identidade e clareza

1. **Parece um produto profissional?** A identidade e o shell são coerentes; textos de especificação e dados DEMO reduzem a percepção de produto concluído.
2. **Quais telas estão incompletas?** Sessões, mensagens e várias abas ainda usam esqueletos/notas. O workspace decisório já tem implementação de demonstração.
3. **A hierarquia visual funciona?** Os h1 do shell têm 24 px; muitos chips e rótulos menores competem com o conteúdo central.
4. **O texto fala a língua do usuário?** Parcialmente; RF/CA, classes e notas de matriz precisam sair do caminho principal.
5. **A identidade deve ser refeita?** Não há evidência para isso. Melhorar hierarquia e densidade preserva marca, creme e glifos.
6. **DEMO e produção ficam claros?** Há selo de demonstração; explicitar que alterações se perdem ao recarregar é necessário.

### Navegação e entrada

7. **As funções estão organizadas?** Sim, por grupos; a amplitude ainda pede priorização por papel e frequência.
8. **Existe busca acessível no celular?** Há acesso no shell; sucesso de encontrar conteúdo real não foi validado.
9. **A próxima ação está clara?** A caixa de atenção ajuda; o workspace pode torná-la mais evidente e concreta.
10. **O cadastro é fácil?** Formulário e rótulos existem; abandono e sucesso real não foram medidos.
11. **Há primeiro uso orientado?** Não foi demonstrado onboarding operacional completo; propor checklist vinculado à primeira decisão real.
12. **Permissões visuais correspondem às reais?** Não é possível concluir: o perfil auditado é de laboratório e a API decisória ainda não existe.

### Decisão e explicabilidade

13. **A pergunta é o centro?** Sim, card e workspace a destacam.
14. **Evidência é separada de hipótese?** O modelo e a UI fazem essa separação; fontes reais não foram auditadas.
15. **Alternativas são comparáveis?** Sim no DEMO, com critérios e pesos.
16. **Os pesos são validados?** Sim; o E2E verificou o aviso quando a soma passa para 105%.
17. **Trade-offs são visíveis?** Há painel de prós/contras e análise de sensibilidade.
18. **A recomendação é compreensível?** Sua estrutura é inspecionável; compreensão por usuários ainda precisa de teste.
19. **A incerteza é expressável?** Há confiança, risco e premissas; evitar que a precisão numérica seja lida como garantia.
20. **Existe responsável humano?** Sim no agregado e no workspace DEMO; vinculação real ao usuário autenticado é pendente.
21. **O momento da decisão fica preservado?** Há código de snapshot/hash; durabilidade e proteção de produção não foram demonstradas.
22. **A decisão vira execução?** Links/checkpoints estão previstos na estrutura; fluxo real integrado não foi validado.
23. **Existe revisão e aprendizagem?** UI/modelo incluem revisão e retrospectiva; ciclo real e efeito no trabalho não foram demonstrados.
24. **Uma decisão pode ser auditada por outra pessoa?** No exemplo, a estrutura é visível. Compartilhamento autorizado e histórico persistente são pré-requisitos pendentes.

### Colaboração e IA

25. **Duas pessoas conseguem deliberar de verdade?** Não demonstrado; dados atuais são locais à aba.
26. **Conflitos de edição são tratados?** Não foram exercitados entre usuários reais; exigir versão otimista e recuperação.
27. **A IA está conectada?** O próprio produto informa que o serviço de desafio ainda não está conectado.
28. **A IA decide pelo usuário?** O desenho prevê sugestão e aceite humano; manter essa regra no backend quando a integração existir.
29. **Origem, custo e privacidade da IA são claros?** Há intenção e documentação; operação/evaluation reais permanecem pendentes.
30. **A gamificação incentiva qualidade?** Não foi medida. Revisar incentivos para evitar premiar volume ou adesão à IA.

### Acessibilidade, performance e evidência

31. **O que foi medido e o que é hipótese?** Medidas locais e capturas são diretas; repositórios/endpoints foram inspecionados; impacto em usuários e causas exatas de CLS são hipóteses a validar.
32. **Funciona em celular e tablet?** Nenhum overflow na amostra; celular ainda apresenta grande profundidade de leitura e alvos pequenos.
33. **É acessível?** Há boa base e flip testado; sem auditoria assistiva/AA completa, não afirmar conformidade.
34. **É rápido e estável?** LCP local baixo; CLS alto no tablet/desktop impede nota elevada. Performance real é desconhecida.
35. **Qual é a principal prioridade?** Persistir e proteger a jornada decisória, junto com a retirada de documentação técnica da experiência normal.
36. **Como saber que chegou a 10?** Todos os critérios da seção 6 demonstrados, sem P0 aberto, com usuários reais e resultados sustentados por duas releases.

## 10. Capturas e rastreabilidade

Os mesmos números identificam destinos nas três famílias `celular-XX.png`, `tablet-XX.png` e `desktop-XX.png`.

| Nº | Destino | Evidência visual |
|---|---|---|
| 01 | `/login` | Título visual, Q-30 e RF no formulário |
| 02 | `/register` | Cadastro e documentação de requisito |
| 03 | `/mural` | Shell e conteúdo social DEMO |
| 04 | `/search` | Busca e abas |
| 05 | `/tasks` | Acervo de tarefas |
| 06 | `/decia` | Caixa de atenção, cards e bloco técnico |
| 07 | `/decia?tab=decisoes` | Quadro de decisões |
| 08 | `/decia/decisoes/d-arquitetura` | Workspace completo no celular e desktop |
| 09 | `/decia?tab=sessoes` | Estado de esqueleto de sessões |
| 10 | `/decia?tab=revisoes` | Revisões/checkpoints DEMO |
| 11 | `/settings` | Preferências e densidade |
| 12 | `/messages` | Mensagens e estado provisório |

Principais fontes de código: `components/shell/RfPage.tsx`, `components/shell/PageHeader.tsx`, `styles/tokens-ws.css`, `components/decia/DecisionCard.tsx`, `DecisionWorkspace.tsx`, `CriteriaMatrix.tsx`, `Analysis.tsx`, `lib/decia/repository.ts`, `commands.ts`, `rules.ts`, `lib/social/repository.ts`, `lib/viewer/ViewerProvider.tsx`, `app/(shell)/decia/page.tsx`, `lib/i18n/messages/pt-BR.json`, `e2e/decia.spec.ts`, `.github/workflows/ci.yml`.

A etapa inicial de levantamento preservou a lógica e os testes do produto. Os documentos e as evidências foram depois versionados em `docs/auditoria/2026-10-11`. As propostas acima se referem ao baseline; as implementações posteriores e seus limites são registradas separadamente em `VALIDACAO.md`, sem declarar que todos os RF estejam concluídos.
