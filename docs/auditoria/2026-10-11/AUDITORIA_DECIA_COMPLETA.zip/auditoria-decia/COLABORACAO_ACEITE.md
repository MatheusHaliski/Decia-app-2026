# Colaboração explícita de tarefas — aceite técnico

Implementado: concessão/revogação pelo proprietário, resolução por nome de usuário, versão da ACL, histórico append-only de acesso, lista “Compartilhadas comigo”, leitura/edição autorizadas e isolamento do histórico de conteúdo.

SIGILOSO não tem exceção global de ADMIN. Um administrador precisa de concessão explícita; essa concessão não permite conceder acesso a outras pessoas. A gestão da ACL e o histórico de conteúdo permanecem exclusivos do proprietário.

Evidências:

- 9 testes MySQL de tarefas, incluindo concessão, revogação, ADMIN sem vínculo, bloqueio da edição que aguardava a revogação e versão obsoleta da concessão.
- 2 testes de interface: concessão/revogação usa a versão recebida; conflito preserva a entrada e não repete a mutação automaticamente.
- [Duas contas reais pelo navegador](COLABORACAO_REAL.json), sem API interceptada: inacessível antes da concessão, leitura e edição após concessão, conteúdo visto pelo proprietário após reload, inacessível depois da revogação. Contas e conteúdo são fictícios; verificação do e-mail foi feita por fixture SQL, sem comprovar entrega SMTP. As contas foram suspensas e suas credenciais descartadas depois do teste; trilha de autenticação preservada.
- Integração completa posterior: 599 testes Java, sem falhas, erros ou testes ignorados; 354 testes de frontend; 28 testes Playwright com API simulada.

Essa entrega implementa acesso colaborativo. Atribuir responsabilidade, aceitar/devolver uma atribuição, projetos/fases, anexos colaborativos e notificações reais exigem seus próprios fluxos e aceites. Não equivale à conclusão de RF10, RF19 ou RF46.
