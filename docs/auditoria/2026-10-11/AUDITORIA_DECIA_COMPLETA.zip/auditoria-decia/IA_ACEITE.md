# Texto assistido por OpenAI — aceite técnico

A proposta fica separada da tarefa, cifrada e vinculada à versão-base e à inferência. O usuário pode revisar título, resumo e descrição, aceitar ou rejeitar. Aceitar grava tarefa, proveniência, histórico e revisão na mesma transação. Propostas antigas ou já revisadas não sobrescrevem conteúdo. Nem gerar nem rejeitar aplica conteúdo automaticamente.

Classificação e autorização vêm da tarefa persistida. RESTRITO/SIGILOSO não são enviados ao provedor externo. PUBLICO/INTERNO exigem confirmação; dados pessoais detectados são mascarados. Notas da tarefa não são enviadas. O usuário é avisado para não incluir conteúdo de maior sigilo no objetivo. Há limites de entrada/saída, corpo de resposta, timeout, orçamento e circuit breaker. Não há repetição automática de POST pago. Falta de créditos tem mensagem específica.

Validação:

- 10 testes de serviço: consentimento, classificação, campos extras, revogação durante inferência, propostas de outro solicitante, versões, aceite, reaplicação e rejeição.
- 3 testes MySQL: proposta cifrada; conteúdo preservado antes do aceite; proveniência após aceite; rejeição; proposta antiga; rollback de conteúdo/histórico se a revisão falha.
- 7 testes do adaptador com servidor HTTP local: formato de requisição, `store=false`, uso de tokens, falhas sem corpo exposto, resposta incompleta/recusa, limites, cota e saída estruturada. Nenhum usa créditos.
- 4 testes de interface: geração não aplica; revisão/editabilidade; bloqueio de proposta antiga; sigilo; falta de créditos sem repetir a chamada.
- [Fluxo real de geração e aceite](IA_REAL_ACEITE.json): uma única chamada paga, com **207 tokens de entrada e 36 de saída**, modelo informado pelo provedor `gpt-4.1-mini-2025-04-14`. Login/BFF/API reais, sem interceptação; conteúdo sintético. Aceite exercitado por teste automático, não por pesquisa com usuários. Email confirmado por fixture SQL; não comprova SMTP. A tarefa foi removida, a conta fictícia suspensa e as credenciais descartadas após o teste, preservando a trilha de autenticação/inferência.
- Integração completa: 599 testes Java, 354 de frontend e 28 Playwright, sem falhas após correções. Build de produção, lint e tipos passaram. Uma verificação do bundle do cliente não encontrou a chave da API.

Limites do aceite: cobre o assistente de texto de uma tarefa existente. Não conclui sozinho criação/upload de todos os tipos, Copilot de projetos, OCR, artefatos, aprendizagem, avaliação da qualidade do modelo ou todos os RF de IA. `store=false` não é garantia de retenção zero pelo provedor. O custo monetário não foi estimado; os tokens acima são os registrados pela API.
