# Notificações persistentes — validação incremental

Data: 12/10/2026. Este documento registra uma entrega incremental; não altera as notas iniciais nem declara concluídos os 48 RF.

## Implementação

- API autenticada lista somente notificações do destinatário, com paginação, categoria e filtro de não lidas.
- A leitura individual exige propriedade. O papel ADMIN não concede acesso à notificação de outra conta.
- A leitura em lote utiliza o instante da lista carregada; itens posteriores permanecem não lidos.
- Concessões e revogações explícitas de colaboração em tarefas produzem notificações na mesma transação. As mensagens contêm apenas texto genérico, identificador do recurso e ação; não copiam conteúdo sigiloso.
- Conceder novamente um acesso já vigente não duplica notificações.
- A interface normal consulta a API. As simulações ficam disponíveis somente no laboratório.
- Sino, central e contador da navegação recebem a contagem real. A central oferece filtros e paginação.
- Respostas atrasadas de contas anteriores são descartadas. Falhas de leitura mantêm itens e contagem para nova tentativa.

## Evidências e limites

Testes locais da interface verificam troca de conta, falha de leitura e envio do instante revisado. Testes do serviço verificam autorização, rejeição de instante futuro e conteúdo genérico. Testes com MySQL verificam isolamento, persistência, leitura idempotente, notificações posteriores e integração com concessão/revogação.

A validação desta entrega não comprova envio de e-mail, push nem emissão por todos os demais fluxos de decisão, prazos, pontos ou mensageria. Esses produtores dependem da implementação dos fluxos correspondentes. Os testes de integração usam contas sintéticas e banco isolado.

Resultados: 4 testes do serviço, 10 testes de persistência/tarefas e 2 verificações de autorização de rotas aprovados, sem falhas ou testes ignorados. Suíte completa da interface: 357 testes em 38 arquivos; após a última alteração de atualização periódica, os 5 testes de notificações foram repetidos e aprovados. Evidência estruturada: `NOTIFICACOES_VALIDACAO.json`. Nenhuma chamada paga de IA foi feita nesta etapa. Não houve nova validação ponta a ponta em navegador nesta etapa.
