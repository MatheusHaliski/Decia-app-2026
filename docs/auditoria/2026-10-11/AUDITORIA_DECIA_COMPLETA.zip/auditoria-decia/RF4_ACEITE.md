# RF4 — rastreabilidade dos critérios de aceite

Os oito critérios foram acrescentados à descrição antes vazia do [RF4 no Trello](https://trello.com/c/ISf39fut/5-rf4-utilizar-o-criador-de-tarefas-escolhendo-o-tipo-do-arquivo-e-editando-detalhes-em-modo-manual-ou-com-ia), como critérios derivados, sem declarar aceite integral. O link oficial está em `TRELLO_ALTERACOES.json` e `rf-inventario.json`.

| Critério | Evidência desta implementação | Lacuna para aceite integral |
|---|---|---|
| CA01 Criador manual | `TaskDraft`, `TaskInventoryService`, `TaskEditor`; proprietário/estado/proveniência definidos no servidor; validação Java e formulário | Seleção de todos os tipos e seus editores específicos |
| CA02 Persistência | `JpaTaskInventory`, testes MySQL; navegador com login/BFF/JWT e API reais, recarga e recuperação após reinício; três revisões cifradas | Validar persistência de anexos e demais tipos ainda não implementados |
| CA03 Concorrência/histórico | Hibernate `@Version`; escrita obsoleta recusada; texto local preservado; revisões cifradas e imutáveis com ator/data/justificativa; restauração gera nova versão; rollback testado | Fluxos de arquivos, IA e projetos ainda não cobertos |
| CA04 Autorização | `ResourceAuthorizer` no serviço; 404 uniforme para tarefa privada; validação de classificação/departamento; âncora empresarial estável; ADMIN sem concessão não acessa SIGILOSO | Cobertura de todas as combinações institucionais e colaboração real |
| CA05 Arquivos | Fundação anterior de inspeção/quarentena no serviço de mídia | Adaptadores, rotas de anexos, UI e integração do scanner |
| CA06 IA | Criação manual de tipo IA rejeitada sem proveniência | Serviço assistido conectado, cotas, fontes e aceite humano |
| CA07 Estados/acessibilidade | Carregamento/erro/vazio, formulários com rótulos, tradução pt-BR/en/es, controles do DS; viewport celular sem overflow no teste novo | Testes completos de teclado/leitor de tela e todos os editores |
| CA08 Evidências | 16 testes de serviço, seis de persistência, quatro de API; testes de editor/histórico e navegador; tarefa manual real antes/depois de reinício; regressões existentes preservadas | Testes dos fluxos ainda não implementados |

**Situação: parcial.** Testes da interface com API interceptada não são apresentados como integração de navegador com banco real. Resultados consolidados: `VALIDACAO.md`.
