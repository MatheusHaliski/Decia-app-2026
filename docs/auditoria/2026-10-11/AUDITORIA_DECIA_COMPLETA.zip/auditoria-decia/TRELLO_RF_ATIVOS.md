# RF ativos — fonte Trello consultada em 11/10/2026

Board Work Station. 48 cartões ativos da lista Requisitos Funcionais. Cartões arquivados foram preservados no board e não reinterpretados como RF atuais. Nenhum cartão foi alterado.

## RF1: Cadastrar usuário na plataforma com dados de acesso

https://trello.com/c/qnpw5aBJ/2-rf1-cadastrar-usu%C3%A1rio-na-plataforma-com-dados-de-acesso

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF2: Autenticar usuário na plataforma com credenciais de acesso

https://trello.com/c/iu9I5vEk/3-rf2-autenticar-usu%C3%A1rio-na-plataforma-com-credenciais-de-acesso

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF3: Editar informações pessoais e preferências do perfil do usuário

https://trello.com/c/hzE41lcX/4-rf3-editar-informa%C3%A7%C3%B5es-pessoais-e-prefer%C3%AAncias-do-perfil-do-usu%C3%A1rio

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF4: Utilizar o criador de tarefas, escolhendo o tipo do arquivo e editando detalhes, em modo manual ou com IA

https://trello.com/c/ISf39fut/5-rf4-utilizar-o-criador-de-tarefas-escolhendo-o-tipo-do-arquivo-e-editando-detalhes-em-modo-manual-ou-com-ia

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF5: Utilizar o criador de projetos, escolhendo em cada fase do projeto as unidades de tarefa, em modo manual ou com IA

https://trello.com/c/4S3KEMrU/88-rf5-utilizar-o-criador-de-projetos-escolhendo-em-cada-fase-do-projeto-as-unidades-de-tarefa-em-modo-manual-ou-com-ia

**Equivalente no FAI:** RF5 Criar esquema (aba "Criar Look": slots por tipo com uma peça de cada, selects alimentados pelo Closet, modo Manual / Com IA, título, ocasião, estilo, orientação livre, foto opcional, capa = composição das peças, selos vindos das peças, pré-visualização do card, cadastrar nova peça inline, mínimo de 2 peças). **Aba:** Criar Projeto (`/projects/new`).

O **Esquema de Projeto** (= look) é a composição ordenada de tarefas (= peças) até o grupo chegar a um consenso/decisão/produto final. **Os selects de cada fase listam as unidades de tarefa do inventário do usuário (Acervo, RF41)** — exatamente como os slots do look listam as peças do closet.

## Layout do compositor
- **Esquerda — Acervo filtrável** (= Closet Digital no Criar Look): grade de tarefas com thumbnail, tipo, categoria, estado; filtros por categoria, tipo, processo, natureza, departamento, estado; busca; botão **"Cadastrar nova tarefa"** (abre o RF20 em modal e devolve a tarefa já selecionada).
- **Centro — Slots por fase** (= partes do look): 7 fases em colunas — DEMANDA · PLANEJAMENTO · ELABORAÇÃO · ANÁLISE · APROVAÇÃO · EXECUÇÃO · ENCERRAMENTO. Cada fase tem um **select múltiplo pesquisável** cujo conteúdo são as tarefas do meu Acervo **compatíveis com a fase** (mapa categoria→fase, como SLOT_BY_CATEGORY: Ofício/Protocolo → DEMANDA; ETP/TR/Cronograma → PLANEJAMENTO; Projeto básico/Planilha/Parecer → ELABORAÇÃO/ANÁLISE; Ata/Portaria → APROVAÇÃO; Contrato/Vistoria → EXECUÇÃO; Relatório final → ENCERRAMENTO; "Outro" em qualquer fase). Também aceita arrastar da esquerda. Cada item selecionado vira um **ProjectTask** com ordem, responsável, prazo e dependências.
- **Direita — Ficha do projeto** (= título/ocasião/estilo/visibilidade): Título · Emoji/ícone · Objetivo (1 frase) · **Processo** (≤2, = ocasião) · **Natureza** (≤2, = estilo) · Departamento · Exercício · Programa (RF25) · Eixo do plano anual (RF24) · Prioridade · Visibilidade (herdada do perfil, RF3) · **Modo de geração: Manual / Com IA** · Orientação livre para a IA ("ex.: pavimentação com recurso do FINISA, 90 dias, sem desapropriação") · Foto/imagem do projeto (opcional, como um post) · Chancelas do projeto (= selos do look: **a chancela vem da tarefa**, RF39) · **Pré-visualização do card** (capa-mosaico + barra de fases, RF38).

## Critérios de aceite
- **RF21.CA01** Dado um empregado com ao menos 2 tarefas DISPONÍVEIS no Acervo, quando abre Criar Projeto, então vê o Acervo filtrável à esquerda, os 7 selects de fase vazios no centro e a ficha à direita.
- **RF21.CA02** Dado um empregado com menos de 2 tarefas, quando abre Criar Projeto, então o sistema orienta o cadastro de tarefas (RF20) com atalho e não apresenta o compositor vazio sem explicação.
- **RF21.CA03** Dado o select de uma fase, quando o abro, então ele lista **somente tarefas do meu Acervo** (e as compartilhadas comigo com permissão de uso), com thumbnail, tipo, categoria, estado e prazo, filtradas por compatibilidade com a fase e pesquisáveis por texto; tarefas BLOQUEADAS ou ARQUIVADAS aparecem desabilitadas com o motivo.
- **RF21.CA04** Dado que selecionei tarefas em ≥2 fases (obrigatoriamente DEMANDA + outra), quando informo título, ≥1 processo e salvo, então o esquema é criado com a lista de ProjectTasks (fase, ordem, responsável = dono da tarefa por padrão, prazo = prazo da tarefa por padrão), visibilidade herdada do perfil e origem CRIAR_PROJETO; as tarefas passam a EM_USO (RF41).
- **RF21.CA05** Dado que tento salvar sem nenhuma tarefa ou só com DEMANDA, quando aciono salvar, então o sistema recusa e indica o mínimo (1 tarefa em DEMANDA + 1 em outra fase).
- **RF21.CA06** Dado o modo **Com IA**, quando confirmo processo, natureza e (opcional) orientação, então a IA apresenta **3 esquemas distintos usando apenas tarefas do meu Acervo** (respeitando a orientação: materiais citados, prazos, departamento), cada um com fases preenchidas, dependências e justificativa; escolho um, edito e salvo (origem AUTOPILOTO se veio integralmente da IA); log em `ai_inference_log`.
- **RF21.CA07** Dado que uma fase precisa de uma tarefa que não existe no Acervo, quando aciono "Cadastrar nova tarefa" dentro do select, então o RF20 abre em modal e, ao salvar, a tarefa já aparece selecionada naquela fase.
- **RF21.CA08** Dado tarefas selecionadas, quando defino dependências (A antes de B) e prazos, então o sistema impede ciclos, rejeita prazo anterior à predecessora (422) e mostra o caminho crítico na pré-visualização.
- **RF21.CA09** Dado que uma tarefa selecionada possui chancela (RF39), quando compõe o projeto, então a chancela aparece em "Chancelas do projeto" (a chancela vem da tarefa) e a IA pode sugerir a chancela tier PROJETO do mesmo emissor.
- **RF21.CA10** Dado que não enviei foto do projeto, quando salvo, então a capa é o mosaico das tarefas (RF38); com foto, ela vira a capa e passa pelo Estúdio (endireitar/recortar).
- **RF21.CA11** Dado o esquema salvo, quando publico no Mural, então ele aparece em Buscar/Mural (RF27) respeitando a visibilidade escolhida e recebe interações (RF26).
- **RF21.CA12** Dado o esquema salvo, quando aciono "Abrir sessão DECIA sobre este projeto", então a sessão nasce com tema = objetivo, participantes = responsáveis + chefe, e as tarefas anexadas (RF29); o projeto passa a EM_DECISÃO.
- **RF21.CA13** Dado um modelo público/chancelado ou meu Kit de Processo, quando escolho "Criar a partir de modelo", então os selects vêm pré-preenchidos com cópias/remixes das tarefas (crédito ao autor, RF26/RF40) e posso trocar cada uma pelo equivalente do meu Acervo.
- **RF21.CA14** Dado o compositor, quando saio sem salvar, então o rascunho é preservado (autosave) e recuperado na próxima abertura; o rascunho não gera EM_USO nas tarefas.


## RF6: Acessar e gerenciar o Perfil  Empresarial (Acervo Digital + Projetos Salvos)

https://trello.com/c/B6vdEe08/21-rf6-acessar-e-gerenciar-o-perfil-empresarial-acervo-digital-projetos-salvos

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF7: Abrir um esquema de tarefa a partir da lista de um esquema de projeto

https://trello.com/c/HPpVyor2/8-rf7-abrir-um-esquema-de-tarefa-a-partir-da-lista-de-um-esquema-de-projeto

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF8: Editar arquivos de tarefas ou projetos dentro de meu perfil do Work Station

https://trello.com/c/9IrAGN3O/9-rf8-editar-arquivos-de-tarefas-ou-projetos-dentro-de-meu-perfil-do-work-station

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF9: Permitir que um chefe de departamento possa adicionar ou remover um usuário da sua lista de empregados atuais

https://trello.com/c/ru5aCEvH/10-rf9-permitir-que-um-chefe-de-departamento-possa-adicionar-ou-remover-um-usu%C3%A1rio-da-sua-lista-de-empregados-atuais

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF10: Permitir que o chefe de departamento possa atribuir uma tarefa ou projeto a um usuário

https://trello.com/c/oxQoqqxs/11-rf10-permitir-que-o-chefe-de-departamento-possa-atribuir-uma-tarefa-ou-projeto-a-um-usu%C3%A1rio

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF11: Utilizar o editor de arte de fundo para personalizar esquemas de tarefas e projetos

https://trello.com/c/FJGkolM1/12-rf11-utilizar-o-editor-de-arte-de-fundo-para-personalizar-esquemas-de-tarefas-e-projetos

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF12: Editar um esquema de tarefa ou projeto de meu perfil

https://trello.com/c/RLpHskWj/13-rf12-editar-um-esquema-de-tarefa-ou-projeto-de-meu-perfil

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF13: Utilizar a funcionalidade gerar artefato dentro de esquemas, chats, abas e feed do Work Station

https://trello.com/c/DA9c7j6d/14-rf13-utilizar-a-funcionalidade-gerar-artefato-dentro-de-esquemas-chats-abas-e-feed-do-work-station

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF14: Visualizar perfil de um chefe de departamento

https://trello.com/c/JYwGI5GL/15-rf14-visualizar-perfil-de-um-chefe-de-departamento

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF15: Visualizar perfil de um empresa ou órgão público/privado

https://trello.com/c/dfTwNxaE/16-rf15-visualizar-perfil-de-um-empresa-ou-%C3%B3rg%C3%A3o-p%C3%BAblico-privado

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF16: Visualizar perfil de um usuário comum que é empregado dentro de uma empresa

https://trello.com/c/mwNWoE9a/17-rf16-visualizar-perfil-de-um-usu%C3%A1rio-comum-que-%C3%A9-empregado-dentro-de-uma-empresa

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF17: Visualizar esquemas de tarefa & projetos criados por outros usuários na rede social do Work Station, através da aba "Buscar"

https://trello.com/c/fAcLoTSo/7-rf17-visualizar-esquemas-de-tarefa-projetos-criados-por-outros-usu%C3%A1rios-na-rede-social-do-work-station-atrav%C3%A9s-da-aba-buscar

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF18: Interagir socialmente com tarefas e projetos: curtir,comentar,salvar, compartilhar, remixar,retornar e atribuir

https://trello.com/c/I4irBZDT/20-rf18-interagir-socialmente-com-tarefas-e-projetos-curtircomentarsalvar-compartilhar-remixarretornar-e-atribuir

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF19: Curtir, comentar, salvar, compartilhar, retornar, atribuir e remixar tarefas, esquemas de projeto e planos anuais (interações sociais)

https://trello.com/c/4auPFPMJ/93-rf19-curtir-comentar-salvar-compartilhar-retornar-atribuir-e-remixar-tarefas-esquemas-de-projeto-e-planos-anuais-intera%C3%A7%C3%B5es-soci

**Equivalente no FAI:** RF19 Interações sociais (alvo polimórfico PIECE/SCHEME/DNA). **Alvos no Work AI:** TASK, PROJECT, PLAN. **API:** `/api/interactions/{type}/{id}/reactions|comments|saves|shares|remixes|counters`.

## Critérios de aceite
- **RF26.CA01** Curtir/descurtir tarefa, projeto ou plano (1 reação por usuário e alvo, índice único).
- **RF26.CA02** Reações qualitativas: ÚTIL, BEM FUNDAMENTADO, INOVADOR, CONFORME (substituem TREND/ELEGANTE/CRIATIVO).
- **RF26.CA03** Comentários com resposta (thread), edição, exclusão pelo autor ou pelo chefe do departamento; menções @usuário geram notificação.
- **RF26.CA04** Salvar em *Tarefas salvas* / *Projetos salvos* com marcador de favorito.
- **RF26.CA05** Compartilhar: no **Mural** da empresa (RF27), **dentro de uma sessão DECIA** (RF29) ou por **link externo** com imagem exportada (capa + resumo) e controle de expiração.
- **RF26.CA06** **Remixar** um projeto ou tarefa pública: cria cópia com `originalId` e crédito visível; o autor original vê "remixado por N pessoas".
- **RF26.CA07** Contadores (curtidas, comentários, salvos, compartilhamentos, remixes) em tempo quase real nos cards e no perfil.
- **RF26.CA08** Interações respeitam a visibilidade: item PRIVADO não recebe interações de terceiros; item DEPARTAMENTO só de membros do departamento.
- **RF26.CA09** Toda interação gera notificação ao dono (agrupada por hora) e alimenta o perfil deliberativo (objetivo 2) — reações BEM FUNDAMENTADO e CONFORME pesam na métrica de qualidade.


## RF20: Utilizar o construtor de projetos do Work Station para compreender se as tarefas de meu acervo são adequadas dentro de meu ambiente empresarial

https://trello.com/c/iT3DdKaH/87-rf20-utilizar-o-construtor-de-projetos-do-work-station-para-compreender-se-as-tarefas-de-meu-acervo-s%C3%A3o-adequadas-dentro-de-meu

**Equivalente no FAI:** RF4 Adicionar peça (foto → IA pré-preenche → formulário com taxonomia oficial → "Mais detalhes" → Closet) + RF11 Background Studio + buscador web de marcas. **Aba:** Criar Tarefa (`/tasks/new`; também pela folha "+ Criar" e pelo botão "Cadastrar nova tarefa" dentro do Criador de Projetos, RF21). O inventário resultante é o **Acervo de Tarefas (RF41)**.

A **tarefa** é a unidade mínima do Work AI (= peça de roupa). O Criador de Tarefas transforma qualquer coisa que circula num escritório comum — arquivo do Windows, documento do Google/Microsoft, e-mail, link, foto do celular, número de protocolo — em uma unidade catalogada, com metadados profissionais e pronta para compor projetos e entrar no DECIA.

## Etapa 1 — Fonte (= "envie uma fotografia")
Zona de entrada única, com abas:
- **Arquivo (Windows/macOS)** — arrastar do Explorer/Finder ou selecionar; formatos: .docx/.xlsx/.pptx/.pdf/.txt/.md/.csv/.msg/.eml/.zip/.png/.jpg/.dwg/.dxf/.ifc/.glb (limite configurável, padrão 50 MB; zip 200 MB).
- **Colar (Ctrl+V)** — texto, tabela copiada do Excel/Sheets ou captura de tela da área de transferência.
- **Google Workspace** — seletor do Drive (Docs, Sheets, Slides, Forms, PDFs) e link de Gmail/Agenda; o item fica **vinculado** (pré-visualização ao vivo, versão sincronizada) ou **copiado** (snapshot).
- **Microsoft 365** — seletor do OneDrive/SharePoint (Word, Excel, PowerPoint), e-mail do Outlook e link de mensagem/canal do Teams; mesma opção vincular/copiar.
- **E-mail → tarefa** — encaminhar para um endereço do sistema (`tarefas+<usuário>@workai…`) ou colar o .eml/.msg: assunto vira título, corpo vira descrição, anexos viram tarefas filhas ou anexos.
- **Link** — URL pública ou interna (favicon, título, captura).
- **Protocolo** — número do e-Protocolo/SEI ou de processo: o sistema cria a tarefa de referência com metadados básicos e link para o sistema de origem.
- **Foto/scanner do celular** — via QR: fotografar ofício/planta/vistoria; **Estúdio de Documento** (= Flat Lay/Estúdio): endireitar, recortar, melhorar contraste, remover fundo de foto de vistoria, OCR.
- **Texto com IA** — escrever um pedido e escolher até 5 tarefas de referência do acervo; a IA redige (ofício, parecer, ata, TR…) no padrão do departamento.

## Etapa 2 — Detecção por IA (= RF4.CA02)
A IA lê a fonte e **pré-preenche**: tipo, categoria, subcategoria, título, resumo (3 linhas), departamento provável, órgão/fornecedor citado, partes envolvidas, datas e **prazo legal**, valor envolvido, palavras-chave, classificação de sigilo sugerida; tudo editável, com nível de confiança e a faísca ✦.

## Etapa 3 — Dados da tarefa (= dados da peça, taxonomia oficial)
| Campo FAI | Campo Work AI | Regra |
|---|---|---|
| Nome | **Título** | obrigatório |
| Categoria / Subcategoria | **Categoria / Subcategoria** (taxonomia oficial: Ofício/Memorando, Parecer técnico, ETP, Termo de referência, Planilha orçamentária, Projeto básico/executivo, Cronograma, Ata, Portaria/Resolução, Contrato/Convênio, Vistoria/Relatório fotográfico, Licença/Anuência, Mapa/Georreferência, Formulário, Outro) | obrigatório; subcategoria depende da categoria |
| Tipo (foto) | **Tipo** (TEXTO_MANUAL, TEXTO_IA, IMAGEM_WEB, IMAGEM_EDITADA, PLANILHA, DOCUMENTO, PASTA, LINK, DESENHO_TECNICO, FORMULARIO, ATA/REGISTRO, E-MAIL, PROTOCOLO) | detectado pela fonte, editável |
| Marca (buscador web) | **Órgão / entidade / fornecedor** com busca web (Wikidata, CNPJ, site oficial) e logo tratado | opcional |
| Cor | **Classificação de acesso** (PÚBLICO, INTERNO, RESTRITO, SIGILOSO — LGPD), sempre com o nome em texto | obrigatório |
| Material | **Formato** (docx, xlsx, pdf, gdoc, gsheet, url…) | automático |
| Tamanho | **Porte** (P/M/G: esforço estimado em horas) | opcional |
| Sexo | — (não se aplica) | — |
| Ocasião (≤2) | **Processo** (≤2): Licitação, Convênio, Obra, Regularização fundiária, Planejamento urbano, Orçamento, Pessoal, Jurídico… (lista por categoria) | obrigatório ≥1 |
| Estilo (≤2) | **Natureza** (≤2): Técnica, Jurídica, Financeira, Administrativa, Ambiental, Social | obrigatório ≥1 |
| Preço (R$) | **Valor envolvido (R$)** | 0 se não se aplica |
| Mercado | **Origem** (INTERNA, ÓRGÃO EXTERNO, FORNECEDOR, CIDADÃO) | opcional |
| — | **Departamento**, **Responsável** (padrão: eu), **Prazo** (com prazo legal calculado por categoria), **Prioridade** | prazo obrigatório quando a categoria tem prazo legal |

## Etapa 4 — Mais detalhes (= selos, visibilidade, estado, compra, tags, notas)
Chancelas sugeridas pela IA por comparação com modelos chancelados (RF39) · Visibilidade (PRIVADA / DEPARTAMENTO / EMPRESA / PÚBLICA) · Estado inicial (RASCUNHO / DISPONÍVEL) · **Situação do documento** (= condição: MINUTA, REVISADO, ASSINADO, PUBLICADO) · Data de recebimento (= data de compra) · Origem/remetente (= local de compra) · **Nº de protocolo/processo** (= SKU) · **Guarda e temporalidade** (= cuidados: prazo de retenção, destinação) · **Oferecer no Balcão** (= à venda, RF40) · Tags · Notas · Dependências (tarefas predecessoras) · Vínculo a projeto e fase (opcional, direto do criador).

## Etapa 5 — Arte do card (= Background Studio)
Thumbnail automático (RF38) ou capa manual/gerada por IA; skin do card; pré-visualização do card antes de salvar.

## Critérios de aceite
- **RF20.CA01** Dado um empregado autenticado em Criar Tarefa, quando envia um arquivo pelo Explorer/Finder ou seleciona no Drive/OneDrive, então o sistema aceita os formatos listados até o limite, rejeita os demais com mensagem clara e bloqueia arquivos maliciosos.
- **RF20.CA02** Dado o upload/seleção concluído, quando a detecção por IA retorna, então tipo, categoria, título, resumo, prazo legal, órgão e classificação vêm pré-preenchidos, editáveis, com confiança e faísca ✦, e o log fica em `ai_inference_log`.
- **RF20.CA03** Dado que a IA não reconhece com confiança suficiente (ou está indisponível), quando a detecção retorna, então o formulário aparece vazio com aviso de preenchimento manual, sem bloquear o cadastro.
- **RF20.CA04** Dado que preenchi os obrigatórios (título, categoria, classificação, ≥1 processo, ≥1 natureza, prazo quando exigido), quando salvo, então a tarefa é persistida e aparece imediatamente no Acervo (RF41) e, se indicado, no projeto/fase escolhido (RF21).
- **RF20.CA05** Dado que enviei vários arquivos ou um .zip, quando concluo o envio, então o sistema cria um rascunho por arquivo (ou uma PASTA com opção "explodir em N tarefas") e permite revisar cada um antes de confirmar o lote.
- **RF20.CA06** Dado que colei texto/tabela/captura (Ctrl+V), quando confirmo, então a tarefa nasce como TEXTO_MANUAL, PLANILHA ou IMAGEM_EDITADA respectivamente, com o conteúdo preservado.
- **RF20.CA07** Dado um Google Doc/Sheet ou Word/Excel vinculado (não copiado), quando a origem muda, então a pré-visualização e o thumbnail são atualizados (sincronização com token OAuth do usuário) e a versão fica registrada; revogar o acesso converte o vínculo em snapshot.
- **RF20.CA08** Dado um e-mail encaminhado ou colado, quando processado, então assunto → título, corpo → descrição, remetente → origem, anexos → anexos ou tarefas filhas (à escolha), e a thread fica referenciada.
- **RF20.CA09** Dado um número de protocolo/processo, quando informado, então a tarefa tipo PROTOCOLO é criada com link para o sistema de origem e os campos básicos; se houver integração disponível, os metadados são lidos automaticamente.
- **RF20.CA10** Dado um órgão/fornecedor digitado, quando aciono a busca web, então vejo candidatos com fonte (Wikidata/CNPJ/site) e logo tratado; escolho um e ele entra na tarefa com referência externa.
- **RF20.CA11** Dado que escolhi uma categoria com prazo legal, quando informo a data-base, então o vencimento é calculado e explicado ("15 dias úteis a partir do recebimento — base legal X"); posso sobrescrever com justificativa.
- **RF20.CA12** Dado que o serviço de OCR/Estúdio de Documento está indisponível, quando salvo, então a tarefa é salva com o arquivo original e um job de reprocessamento fica pendente (aviso no card).
- **RF20.CA13** Dado que a IA sugere chancelas (RF39) na etapa Mais detalhes, quando aceito uma, então o vínculo nasce SUGERIDA→ACEITA e segue a política do emissor; recusar não bloqueia o cadastro.
- **RF20.CA14** Dado um erro de validação, quando tento salvar, então os campos destacados mostram mensagem específica (i18n) e a API responde 422 com `details` por campo e `correlationId`.
- **RF20.CA15** Dado que marquei "Oferecer no Balcão", quando salvo, então a tarefa aparece na sub-aba Modelos oferecidos (RF40) com preço em pontos e licença.


## RF21: Utilizar a mesa de trabalho digital de meu perfil

https://trello.com/c/45z7hrqa/6-rf21-utilizar-a-mesa-de-trabalho-digital-de-meu-perfil

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF22: Editar um Esquema de Projeto na Mesa de Trabalho (quadro por fase, linha do tempo e canvas livre) com versões e histórico

https://trello.com/c/B7IrvxlZ/89-rf22-editar-um-esquema-de-projeto-na-mesa-de-trabalho-quadro-por-fase-linha-do-tempo-e-canvas-livre-com-vers%C3%B5es-e-hist%C3%B3rico

**Equivalente no FAI:** RF9 Editar esquema + RF15 Editor Canvas 2D + RF27 Meu Quarto. **Abas:** `/projects/[id]/edit` e Mesa de Trabalho (`/desk`).

## Três visões do mesmo projeto
1. **Quadro** (kanban por fase) — colunas DEMANDA…ENCERRAMENTO, arrastar e soltar.
2. **Linha do tempo** — barras por tarefa com prazo, dependências e caminho crítico (Gantt simples).
3. **Mesa** (canvas livre) — tarefas como cartões/post-its com posição, escala e rotação livres, conectores de dependência, textura de mesa (papel, cortiça, Blueprint) e skins salvas no perfil (RF38).

## Critérios de aceite
- **RF22.CA01** Só o dono, os responsáveis por tarefas e o chefe do departamento editam; os demais veem somente leitura (403 ACESSO_NEGADO na API).
- **RF22.CA02** Toda alteração estrutural (adicionar/remover/mover tarefa, mudar prazo/responsável) gera uma **versão** com autor, data e diff legível; posso comparar e restaurar versões.
- **RF22.CA03** Mudar de visão (Quadro/Linha do tempo/Mesa) não perde dados; a posição na Mesa é persistida por tarefa (x, y, escala, rotação, camada).
- **RF22.CA04** Edição colaborativa: dois usuários editando veem as alterações um do outro em até 3 s (polling ou websocket) e o sistema resolve conflito por último-vence com aviso.
- **RF22.CA05** Comentários por tarefa dentro do projeto e um painel lateral com o **fio de decisão** da sessão DECIA vinculada (RF29).
- **RF22.CA06** Projeto CONCLUÍDO ou ARQUIVADO fica bloqueado para edição; reabrir exige justificativa registrada no histórico.
- **RF22.CA07** Exportar o projeto como PDF (relatório com fases, tarefas, responsáveis, prazos e decisões) e como ZIP com todos os anexos.


## RF23: Importar tarefas ou projetos outros provedores para dentro de meu perfil do Work Station

https://trello.com/c/tZTRC1CU/90-rf23-importar-tarefas-ou-projetos-outros-provedores-para-dentro-de-meu-perfil-do-work-station

**Equivalente no FAI:** RF7 Peça a partir do esquema.

## Critérios de aceite
- **RF23.CA01** Em qualquer projeto visível para mim, cada tarefa tem a ação **"Levar ao meu acervo"**: cria uma cópia no meu Acervo com `origem = EXTRAÍDA_DE_PROJETO`, crédito ao autor original e link para o projeto de origem.
- **RF23.CA02** A cópia herda tipo, categoria, anexos (referência, não duplicação de arquivo) e tags; o estado inicial é DISPONÍVEL e a visibilidade PRIVADA.
- **RF23.CA03** Quando o dono exclui uma tarefa que está em projetos de outras pessoas, cada ProjectTask mantém um **snapshot** (título, tipo, categoria, thumbnail, resumo) e o projeto exibe a tarefa como "removida pelo autor" sem quebrar fases nem dependências.
- **RF23.CA04** O contador de reutilizações da tarefa original é incrementado e aparece no card e no perfil deliberativo do autor (métrica de reutilização, objetivo 2).
- **RF23.CA05** Tarefas com visibilidade PRIVADA não podem ser extraídas; a API responde 403 e a ação não aparece na tela.


## RF24: Visualizar a aba metas & objetivos de minha equipe com insights analíticos gerados por IA

https://trello.com/c/hwTL1zla/91-rf24-visualizar-a-aba-metas-objetivos-de-minha-equipe-com-insights-anal%C3%ADticos-gerados-por-ia

**Equivalente no FAI:** RF13 DNA de Estilo (6 células). **Aba:** Plano Anual (`/plans`, `/plans/new`, `/plans/[id]`).

O **Plano Anual** é o "DNA" da empresa ou do empregado: 6 eixos estratégicos (células) que recebem projetos (= looks). A empresa publica o plano oficial; chefes de departamento criam o plano do departamento; empregados criam a trilha pessoal derivada.

## Critérios de aceite
- **RF24.CA01** Crio um plano com exercício (ano), título e 6 eixos nomeados (ex.: Mobilidade, Habitação, Saneamento, Regularização fundiária, Equipamentos públicos, Gestão interna); cada eixo tem meta, indicador e cor.
- **RF24.CA02** Arrasto projetos meus, do departamento ou da empresa para os eixos; um projeto pode estar em 1 eixo por plano.
- **RF24.CA03** O plano mostra por eixo: nº de projetos, % concluídos, prazo mais próximo e risco agregado (da IA, RF31/RF32).
- **RF24.CA04** Plano da EMPRESA é o oficial: chefes e empregados podem **derivar** (duplicar) o plano para o departamento/pessoal mantendo o vínculo com o oficial.
- **RF24.CA05** Comparação lado a lado de dois exercícios (2025 × 2026) com projetos novos, concluídos e reprogramados.
- **RF24.CA06** Interações sociais (RF26) e chancela (RF28) valem para o plano; o plano tem visibilidade e capa.
- **RF24.CA07** A IA do DECIA cita o eixo do plano ao recomendar decisões (objetivo 3) e sinaliza projetos sem eixo.


## RF25: Agrupar projetos e tarefas em Programas, Exercícios e Gestões (agrupamentos institucionais)

https://trello.com/c/xK0i4VC9/92-rf25-agrupar-projetos-e-tarefas-em-programas-exerc%C3%ADcios-e-gest%C3%B5es-agrupamentos-institucionais

**Equivalente no FAI:** Agrupamentos (Coleções da marca RF35, Eras da celebridade RF34, temporadas). **Sub-aba:** Programas & Agrupamentos no perfil (RF19).

## Tipos de agrupamento
- **PROGRAMA** (= coleção) — criado pela EMPRESA ou pelo CHEFE (ex.: "Programa Cidade Acessível 2026").
- **EXERCÍCIO** (= temporada) — ano orçamentário.
- **GESTÃO** (= era) — período de um chefe de departamento ou de uma gestão da empresa.
- **FRENTE** (= linha de estilo) — tema transversal (ex.: "Convênios federais").

## Critérios de aceite
- **RF25.CA01** EMPRESA e CHEFE criam agrupamentos com nome, tipo, período, capa e descrição; empregados só criam FRENTE pessoal.
- **RF25.CA02** Projetos e tarefas apontam para um agrupamento (`grouping_id`); um item pode estar em vários agrupamentos de tipos diferentes (1 programa + 1 exercício + 1 gestão).
- **RF25.CA03** A página do agrupamento mostra capa, projetos em grade, progresso agregado e a linha do tempo de decisões (RF29).
- **RF25.CA04** Agrupamentos aparecem na página da empresa/departamento (RF28) e são pesquisáveis (RF27).
- **RF25.CA05** Encerrar uma GESTÃO gera automaticamente o **Dossiê de Transição** (RF36) do período.


## RF26: Utilizar o Copilot do WS para criar sugestões de tarefas e projetos de maneira mais prática e funcional

https://trello.com/c/O2bl1Xsh/86-rf26-utilizar-o-copilot-do-ws-para-criar-sugest%C3%B5es-de-tarefas-e-projetos-de-maneira-mais-pr%C3%A1tica-e-funcional

**Equivalente no FAI:** RF6 Perfil Lookbook (+ RF17 perfil de outros). **Aba:** Meu perfil (`/profile`, perfil de outros em `/u/[username]`).

O perfil é o registro de tudo o que o empregado produziu desde que entrou no sistema: tarefas, projetos, planos, participação em sessões DECIA e o perfil deliberativo (objetivo 2). No cabeçalho, o **Hype Score do Perfil** (RF45) aparece se o dono escolher exibi-lo.

## Sub-abas
**Visíveis para todos** (respeitando visibilidade de cada item):
1. **Acervo de Tarefas** — grade de tarefas públicas (filtros: estado, categoria, tipo) (RF41)
2. **Meus Projetos** — esquemas de projeto (filtros: fase, estado [favoritos, publicados, rascunhos, arquivados], exercício, departamento)
3. **Programas & Agrupamentos** — programas, exercícios, gestões (RF25)
4. **Decisões** — decisões validadas de sessões DECIA em que participou, com o fio de decisão (RF29)
5. **Perfil deliberativo (resumo)** — medalhas e indicadores públicos escolhidos pelo dono

**Só o dono (self):**
6. **Meus Planos Anuais / Trilhas** (RF24)
7. **Projetos salvos**
8. **Tarefas salvas**
9. **Tarefa do Dia** — a tarefa sugerida pela IA para hoje, feedback CONCLUÍ / ADIEI / BLOQUEADA / DELEGUEI, **Hype Score de Eficiência** previsto × realizado, média móvel de 7 dias e semana planejada (= Look do Dia + Hype Score) (RF44)
10. **Kits de Processo** (= Cápsula) — conjuntos mínimos de tarefas reutilizáveis
11. **Meus modelos oferecidos** (= peças à venda) (RF40)
12. **Meus Reconhecimentos e Chancelas** (= cupons e selos) (RF35, RF39)
13. **DECIA Points** — saldo, extrato e Loja (RF42)
14. **Hype Score do Perfil** — score 0–1000, faixa, decomposição (produção, reconhecimento social, DECIA, eficiência, reconhecimentos), histórico e controle de exibição PÚBLICO / EMPRESA / SÓ EU (RF45)
15. **Perfil deliberativo (completo)** — clareza argumentativa, uso de evidências, consistência entre sessões, completude e reutilização de tarefas/projetos; gráfico de evolução por sessão/projeto; insights da IA (RF43)

## Critérios de aceite
- **RF19.CA01** Dado um empregado autenticado, ao abrir *Meu perfil* vejo cabeçalho (avatar, nome, cargo, empresa, departamento, contadores: tarefas, projetos, decisões, seguidores, DECIA Points, Hype Score se exibido) e as 15 sub-abas.
- **RF19.CA02** Ao abrir o perfil de outro usuário (`/u/[username]`) vejo somente as sub-abas 1–5, apenas itens com visibilidade PÚBLICA ou EMPRESA (se for da mesma empresa) e o Hype Score só se o dono o exibir para o meu nível (RF45).
- **RF19.CA03** Cada sub-aba tem filtros próprios e paginação; a URL guarda a sub-aba e os filtros ativos.
- **RF19.CA04** A sub-aba *Tarefa do Dia* registra 1 tarefa por dia (índice único usuário+data); o feedback e o esforço real calculam o Hype Score de Eficiência realizado (RF44) e alimentam a IA na próxima sugestão.
- **RF19.CA05** O perfil deliberativo mostra as métricas do objetivo 2 com variação entre a sessão atual e a anterior (▲▼) e um gráfico de linha por mês.
- **RF19.CA06** Perfis de EMPRESA e CHEFE DE DEPARTAMENTO mostram sub-abas institucionais adicionais (RF28).
- **RF19.CA07** Todos os textos do perfil são i18n (pt-BR/en/es) e a página é responsiva.


## RF27: Navegar no Mural (mural da empresa e vitrine de projetos) e Buscar projetos, tarefas, pessoas, empresas e chefes de departamento

https://trello.com/c/IpnAnbDh/94-rf27-navegar-no-mural-mural-da-empresa-e-vitrine-de-projetos-e-buscar-projetos-tarefas-pessoas-empresas-e-chefes-de-departamento

**Equivalente no FAI:** Feed (Comunidade/Passarela) + RF8 Buscar/Explorar. **Abas:** Mural (`/mural`) e Buscar (`/search`).

## Mural — sub-abas
1. **Mural da empresa** — compartilhamentos, decisões validadas, projetos publicados e reconhecimentos da minha empresa, em ordem cronológica com filtros (departamento, tipo de item).
2. **Vitrine de projetos** (= Passarela) — projetos chancelados e modelos públicos em destaque, com capa grande e "remixar".
3. **Seguindo** — atividade das pessoas e departamentos que sigo.

## Buscar — abas
PROJETOS · TAREFAS · PESSOAS · EMPRESAS · CHEFES DE DEPARTAMENTO (+ filtros: categoria, tipo, fase, departamento, exercício, chancelado, prazo).

## Critérios de aceite
- **RF27.CA01** O Mural carrega em páginas de 20 itens, com skeleton, estado vazio ilustrado e "tentar de novo" em erro.
- **RF27.CA02** Cada item do mural tem as ações do RF26 inline.
- **RF27.CA03** A busca é textual (título, descrição, tags, conteúdo extraído de documentos por OCR/índice) e retorna as 5 abas com contadores.
- **RF27.CA04** A busca respeita visibilidade e perfil; resultados de outra empresa só aparecem se PÚBLICOS.
- **RF27.CA05** Busca semântica opcional ("projetos parecidos com este") usando a Memória Institucional (RF33).
- **RF27.CA06** Seguir/deixar de seguir pessoas, departamentos e empresas (1 vínculo único).


## RF28: Gerir perfis de empresa e chefe de departamento (departamentos, página institucional, chancela de tarefas/projetos e emissão de reconhecimentos)

https://trello.com/c/PvEX1Blq/95-rf28-gerir-perfis-de-empresa-e-chefe-de-departamento-departamentos-p%C3%A1gina-institucional-chancela-de-tarefas-projetos-e-emiss%C3%A3o-d

**Equivalente no FAI:** RF14 Aba Marcas + RF22 Perfil institucional (+ perfis MARCA/CELEBRIDADE). O fluxo de selos/promoções (RF20/RF21/RF25/RF38 do FAI) fica no **RF39 Chancelas e benefícios**; o "à venda" do usuário comum fica no **RF40 Balcão de Modelos**. **Perfis:** EMPREGADO (= PESSOAL), EMPRESA (= MARCA, ex.: Secretaria das Cidades), CHEFE DE DEPARTAMENTO (= CELEBRIDADE), ADMIN. **Aba:** Empresas & Departamentos (`/companies`, `/companies/[slug]`, `/departments/[slug]`).

## Página da empresa — sub-abas
Sobre · Departamentos (SECID-UTS, CPOE, CFOE, CGPO, DEP…) · Programas (RF25) · Plano Anual oficial (RF24) · Chancelas e modelos oficiais (RF39) · Benefícios (RF39) · Destaques (RF35) · Pessoas.

## Página do departamento / chefe — sub-abas
Sobre · Projetos do departamento · Sessões DECIA (abertas/encerradas) · Chancelas do departamento e fila de revisão (RF39) · Reconhecimentos emitidos (RF35) · Equipe (com curadores).

## Critérios de aceite
- **RF28.CA01** No cadastro (RF1) escolho EMPREGADO, EMPRESA ou CHEFE DE DEPARTAMENTO; EMPRESA e CHEFE passam por verificação do ADMIN antes de publicar (`POST /api/admin/approvals/{userId}`); o frontend mostra menus e rotas por perfil e o backend valida por papel (403 ACESSO_NEGADO).
- **RF28.CA02** A EMPRESA cria e edita departamentos (nome, sigla, cor, monograma, chefe responsável) e vincula empregados a um departamento; um empregado pertence a 1 departamento por vez (histórico de lotações preservado).
- **RF28.CA03** O CHEFE nomeia **curadores** no seu departamento (papel CURADOR): operam a fila de revisão de chancelas e a curadoria de premiação (RF39) em nome do emissor; a nomeação e a revogação ficam em `audit_log`.
- **RF28.CA04** Página institucional pública com as sub-abas acima; seguir empresa/departamento (RF27.CA06); métricas públicas: projetos publicados, modelos oficiais, decisões validadas no período.
- **RF28.CA05** **Reconhecimentos** (= cupons, RF35.CA05): EMPRESA/CHEFE emitem reconhecimentos (nome, medalha, critério, validade) para empregados; aparecem no perfil (RF19) e no Mural.
- **RF28.CA06** Dashboard do emissor (EMPRESA/CHEFE): projetos por fase, prazos em risco, decisões pendentes de revisão (RF15), fila de chancelas (RF39), uso e custo de IA por departamento, benefícios resgatados, com filtros de período e departamento.
- **RF28.CA07** Uma pessoa pode ser CHEFE de mais de um departamento; a troca de chefe move sessões DECIA, filas de revisão e chancelas pendentes para o novo chefe e gera o Dossiê de Transição (RF36).
- **RF28.CA08** Perfil EMPREGADO não acessa o criador de chancela nem o painel do emissor (403), mas acessa Balcão (RF40), indicações e propostas de chancela (RF39.CA06).


## RF29: Integrar o DECIA ao Criador de Projetos — compartilhar tarefas/artefatos na sessão, abrir sessão a partir de um projeto, transformar argumentos/divergências/decisões em tarefas e manter o Rastro de Decisão

https://trello.com/c/9tKndHWU/96-rf29-integrar-o-decia-ao-criador-de-projetos-compartilhar-tarefas-artefatos-na-sess%C3%A3o-abrir-sess%C3%A3o-a-partir-de-um-projeto-transf

**Equivalente no FAI:** RF10 Copilot (origem COPILOT nos esquemas) — aqui elevado a **hub do app**. O DECIA é onde as pessoas trabalham em grupo e compartilham artefatos, tarefas e argumentos rumo a decisões; o Criador de Projetos alimenta a sessão e recebe suas decisões.

## O que muda na sessão DECIA (RF4–RF17)
- Toda mensagem (RF6) pode carregar **anexos do acervo**: tarefas, projetos, planos (visualização inline com thumbnail e ações do RF26).
- A classificação da IA (RF7) passa a ligar o argumento à tarefa/projeto citado ("argumento sobre a tarefa Planilha orçamentária v2").
- Divergências (RF8/RF10), perguntas (RF16), resumo analítico (RF11), decisão final (RF12/RF15) e artefatos (RF13) ganham a ação **"Transformar em tarefa"**.

## Rastro de Decisão (Decision Provenance)
Grafo `DecisionTrace`: mensagem → classificação → tarefa → projeto → decisão → revisão humana. Visualizado como o **fio de decisão** (RF38): linha vertical com nós coloridos por classificação e carimbo VALIDADO/DEVOLVIDO.

## Critérios de aceite
- **RF29.CA01** Em um projeto, o botão **"Abrir sessão DECIA"** cria a sessão com tema = objetivo do projeto, participantes = responsáveis + chefe do departamento, e anexa as tarefas do projeto como contexto da IA; o projeto passa a EM_DECISÃO.
- **RF29.CA02** Em uma sessão, o botão **"Criar projeto a partir desta sessão"** gera um esquema com origem DECIA, tarefas a partir dos artefatos (RF13) e das decisões, já nas fases sugeridas pela IA.
- **RF29.CA03** Ao escrever uma mensagem posso anexar até 5 itens do acervo (tarefa/projeto/plano) por busca rápida ou arrastar; o item aparece inline e quem tem permissão abre o detalhe.
- **RF29.CA04** Qualquer mensagem classificada como argumento, divergência, risco, consenso ou pergunta tem **"Transformar em tarefa"**: abre o formulário do RF20 pré-preenchido (tipo TEXTO_MANUAL ou ATA/REGISTRO, título, descrição = texto da mensagem, fase sugerida) e cria o vínculo `DecisionTrace(mensagem → tarefa)`.
- **RF29.CA05** A decisão final validada (RF15) cria automaticamente uma tarefa ATA/REGISTRO no projeto vinculado, na fase APROVAÇÃO, com carimbo VALIDADO, data e revisor; rejeição cria tarefa com carimbo DEVOLVIDO e o motivo.
- **RF29.CA06** Cada tarefa e projeto exibe o painel **"Por que isto existe?"** com o fio de decisão completo (mensagens, autores, datas, classificação, decisão, revisor), navegável até a mensagem original na sessão (mesmo encerrada, RF17).
- **RF29.CA07** O rastro é imutável (append-only) e exportável em PDF/JSON para auditoria; a exclusão de tarefa mantém o rastro via snapshot (RF23).
- **RF29.CA08** O resumo analítico (RF11) lista, por recomendação, as tarefas e projetos afetados e o eixo do plano anual (RF24).
- **RF29.CA09** Indicador no dashboard (RF18): % de projetos concluídos com decisão registrada em sessão DECIA com rastro completo (métrica do objetivo 1).


## RF30: Gerar um Esquema de Projeto completo com o Autopiloto de Projeto a partir de uma demanda (ofício, e-mail ou frase), reutilizando modelos chancelados

https://trello.com/c/Y2jWtOg2/97-rf30-gerar-um-esquema-de-projeto-completo-com-o-autopiloto-de-projeto-a-partir-de-uma-demanda-of%C3%ADcio-e-mail-ou-frase-reutilizand

**Equivalente no FAI:** Autopiloto + "Vista-me" (RF28). **Aba:** Autopiloto (`/autopilot`).

## Critérios de aceite
- **RF30.CA01** Informo a demanda por texto livre, colando um ofício/e-mail ou anexando um DOCUMENTO do acervo; a IA extrai objetivo, prazo, departamento provável e categoria do processo.
- **RF30.CA02** A IA propõe um esquema completo: fases, tarefas (com tipo e categoria), dependências, responsáveis sugeridos (por histórico do departamento) e prazos, **remixando os modelos chancelados** e os projetos mais bem avaliados semelhantes (RF33), com crédito a cada modelo usado.
- **RF30.CA03** Antes de salvar, vejo a proposta na Mesa de Trabalho (RF22) em modo rascunho e posso aceitar, remover ou trocar cada tarefa; nada é persistido até eu confirmar.
- **RF30.CA04** O projeto criado tem origem AUTOPILOTO, a faísca ✦ e o log de inferência (modelo, custo, latência, modelos de referência) para auditoria.
- **RF30.CA05** Sem chave de IA disponível, o Autopiloto usa o motor local (regras + modelos chancelados) e avisa o usuário do fallback.
- **RF30.CA06** Botão "Abrir sessão DECIA sobre a proposta" para o grupo decidir sobre o esqueleto antes de executar (RF29).


## RF31: Simular cenários sobre um Esquema de Projeto (corte de orçamento, atraso, troca de fornecedor, mudança de escopo) antes de enviá-lo à aprovação

https://trello.com/c/6FEDQHDN/98-rf31-simular-cen%C3%A1rios-sobre-um-esquema-de-projeto-corte-de-or%C3%A7amento-atraso-troca-de-fornecedor-mudan%C3%A7a-de-escopo-antes-de-envi%C3%A1

**Equivalente no FAI:** RF18 Provador 2D (experimentar antes de decidir). **Aba:** Simulador de Cenários (`/projects/[id]/simulate`).

## Critérios de aceite
- **RF31.CA01** A partir de um projeto, crio um cenário escolhendo variáveis: orçamento (±%), prazo (±dias), remoção/adição de tarefa, troca de responsável/fornecedor, mudança de escopo (texto).
- **RF31.CA02** A IA recalcula a linha do tempo, o caminho crítico e o risco de cada fase, e devolve um **relatório de impacto**: tarefas afetadas, novo prazo final, riscos novos, conformidade (RF32) e vantagens/desvantagens — no mesmo formato dos cenários do resumo analítico (RF11).
- **RF31.CA03** Posso comparar até 3 cenários lado a lado e **salvar** um cenário como variante do projeto (não altera o original) ou **aplicar** um cenário (gera versão no histórico, RF22).
- **RF31.CA04** Um cenário pode ser compartilhado na sessão DECIA (RF29) para o grupo decidir entre cenários; a decisão final referencia o cenário escolhido.
- **RF31.CA05** Todo cálculo da IA carrega a faísca ✦ e o log de inferência; o motor local cobre o cálculo de prazo/caminho crítico sem IA externa.


## RF32: Verificar a conformidade de um Esquema de Projeto no Espelho de Conformidade (checklists legais e do departamento) e sugerir as tarefas faltantes

https://trello.com/c/0a2bcFbp/99-rf32-verificar-a-conformidade-de-um-esquema-de-projeto-no-espelho-de-conformidade-checklists-legais-e-do-departamento-e-sugerir

**Equivalente no FAI:** Espelho / Smart Mirror (RF28) — a IA "olha" o projeto e diz o que falta. **Aba:** Espelho de Conformidade (`/projects/[id]/mirror`).

## Critérios de aceite
- **RF32.CA01** EMPRESA e CHEFE mantêm **checklists de conformidade** por categoria de processo (ex.: licitação — Lei 14.133/2021: ETP antes do TR, parecer jurídico antes da APROVAÇÃO, pesquisa de preços; obra — licença ambiental, ART/RRT, projeto básico antes da EXECUÇÃO), com itens obrigatórios/recomendados e fase esperada.
- **RF32.CA02** Ao abrir o Espelho, a IA cruza as tarefas do projeto com os checklists aplicáveis e mostra: ✅ atendido (com a tarefa que atende), ⚠️ recomendado ausente, ⛔ obrigatório ausente ou fora de ordem.
- **RF32.CA03** Cada item ausente tem **"Criar tarefa faltante"**: cria a tarefa na fase esperada, com tipo/categoria já definidos e vínculo ao item do checklist.
- **RF32.CA04** O projeto exibe um **selo de conformidade** (%) no card e a IA bloqueia (com aviso, não impedimento absoluto) a passagem para APROVAÇÃO com ⛔ pendentes; o chefe pode aprovar mesmo assim registrando justificativa (autoridade humana).
- **RF32.CA05** O resultado do Espelho entra no resumo analítico (RF11) e no rastro de decisão (RF29).
- **RF32.CA06** O Espelho também analisa um **projeto de outra pessoa** que eu esteja revisando (chefe), sem editá-lo.


## RF33: Consultar a Memória Institucional (busca semântica sobre sessões encerradas, artefatos, projetos e tarefas) e fazer a IA do DECIA citar fontes institucionais

https://trello.com/c/N4hj9RCT/100-rf33-consultar-a-mem%C3%B3ria-institucional-busca-sem%C3%A2ntica-sobre-sess%C3%B5es-encerradas-artefatos-projetos-e-tarefas-e-fazer-a-ia-do-dec

**Equivalente no FAI:** RF26 Explorador Global + RF24 IA (serviços externos). **Aba:** Memória Institucional (`/memory`). Base do objetivo 3 ("justificativa rastreável correlacionada à base de conhecimento institucional").

## Critérios de aceite
- **RF33.CA01** Tudo que é encerrado ou publicado (sessões RF17, artefatos RF13, decisões RF15, projetos CONCLUÍDOS, tarefas MODELO_PÚBLICO e documentos indexáveis) é indexado em um índice semântico (embeddings) com metadados: empresa, departamento, categoria, exercício, autor, data.
- **RF33.CA02** Pergunto em linguagem natural ("quem já fez convênio de pavimentação com a Caixa?") e recebo respostas com **trechos e links** para a fonte (sessão, tarefa, projeto), respeitando visibilidade e perfil.
- **RF33.CA03** Dentro de uma sessão DECIA, a IA (RF8, RF11, RF16) **cita fontes institucionais** por padrão: cada recomendação traz "baseado em: [sessão X, projeto Y]"; recomendação sem fonte é marcada "sem precedente".
- **RF33.CA04** Explorador visual: mapa/grade por departamento, categoria e exercício, com filtros e "projetos semelhantes a este" (RF27.CA05).
- **RF33.CA05** Indicador no dashboard (RF18): proporção de decisões com fontes institucionais registradas (métrica do objetivo 3).
- **RF33.CA06** Reindexação é assíncrona (evento AFTER_COMMIT) e falhas de indexação não bloqueiam a operação de negócio; log em `ai_inference_log`.


## RF34: Extrair informações de desenhos técnicos e documentos (dwg/dxf/ifc/glb/pdf) com IA para gerar quantitativos, planilha orçamentária e cronograma pré-preenchidos

https://trello.com/c/Ns4jDNtt/101-rf34-extrair-informa%C3%A7%C3%B5es-de-desenhos-t%C3%A9cnicos-e-documentos-dwg-dxf-ifc-glb-pdf-com-ia-para-gerar-quantitativos-planilha-or%C3%A7ament

**Equivalente no FAI:** pipelines de imagem do RF4 (Flat Lay, Estúdio, filtro de logos) e RF16 Geração 3D — aqui aplicados ao artefato de trabalho. **Aba:** ação "Extrair com IA" na tarefa DESENHO_TECNICO / DOCUMENTO (RF20).

## Critérios de aceite
- **RF34.CA01** Em uma tarefa DESENHO_TECNICO (.dwg/.dxf/.ifc) a ação **"Extrair quantitativos"** lê camadas/entidades e devolve uma tabela (item, unidade, quantidade, área/volume) com nível de confiança por linha.
- **RF34.CA02** Em um DOCUMENTO (pdf/docx) a ação **"Extrair itens e prazos"** devolve itens, valores, datas e responsáveis citados (OCR quando necessário).
- **RF34.CA03** O resultado pode virar, com um clique, uma nova tarefa PLANILHA (planilha orçamentária/quantitativos) ou CRONOGRAMA no mesmo projeto, vinculada à tarefa de origem e com a faísca ✦.
- **RF34.CA04** O usuário revisa e corrige a tabela antes de salvar; correções são guardadas para melhorar as próximas extrações do mesmo departamento.
- **RF34.CA05** Modelos 3D (.glb) abrem no visualizador com medição de distância/área; a captura do visualizador pode virar IMAGEM_EDITADA (RF20).
- **RF34.CA06** Toda extração registra modelo, custo e latência em `ai_inference_log`; sem IA externa, o motor local faz a leitura estrutural (camadas/blocos) sem interpretação semântica e avisa.


## RF35: Participar de Metas coletivas, aparecer nos Destaques e receber Reconhecimentos (gamificação ligada ao perfil deliberativo, com DECIA Points como moeda)

https://trello.com/c/zVcjU9KW/102-rf35-participar-de-metas-coletivas-aparecer-nos-destaques-e-receber-reconhecimentos-gamifica%C3%A7%C3%A3o-ligada-ao-perfil-deliberativo-co

**Equivalente no FAI:** RF32 Desafios + Destaques + RF38 Cupons. A moeda é o **DECIA Points (RF42)**, ganho por participação no chat DECIA. **Abas:** Metas coletivas (`/goals`), Destaques (`/highlights`), Reconhecimentos (`/recognitions`).

## Critérios de aceite
- **RF35.CA01** **Metas coletivas** (= desafios): EMPRESA/CHEFE criam uma meta com período, critério mensurável (ex.: "100% dos projetos do exercício com eixo do plano anual", "10 decisões validadas com rastro completo no trimestre") e recompensa (DECIA Points para o grupo e/ou reconhecimento); o progresso é calculado automaticamente e exibido no Mural com barra e participantes.
- **RF35.CA02** Meta atingida credita DECIA Points a cada participante com lançamento idempotente (RF42) e dispara a emissão do reconhecimento configurado.
- **RF35.CA03** **Destaques** do mês: projetos, decisões e pessoas mais bem avaliados por departamento, escolhidos por algoritmo transparente (critérios visíveis: reações BEM FUNDAMENTADO/CONFORME, reutilizações, rastro completo, conformidade) + curadoria do chefe; aparecem na Vitrine (RF27) e alimentam a Chancela de Excelência (RF39).
- **RF35.CA04** **Reconhecimentos** (= cupons): EMPRESA/CHEFE emitem reconhecimentos (nome, medalha, critério, validade) para empregados — manualmente, por meta atingida ou por benefício de chancela (RF39); aparecem como medalhas no perfil (RF19) e no Mural.
- **RF35.CA05** O perfil deliberativo (RF19.CA12) mostra metas cumpridas, destaques recebidos e reconhecimentos, ao lado dos DECIA Points por origem, ligando a gamificação ao objetivo 2 (clareza, evidências, consistência).
- **RF35.CA06** Anti-abuso: metas não podem ser criadas com critério trivial (mínimo de esforço definido pela empresa), reconhecimentos têm limite por emissor/mês e toda emissão é auditada.


## RF36: Gerar o Dossiê de Transição (handoff) quando um empregado muda de departamento, sai ou uma gestão encerra, transferindo projetos, tarefas e pendências com contexto

https://trello.com/c/Jtjj31Iv/103-rf36-gerar-o-dossi%C3%AA-de-transi%C3%A7%C3%A3o-handoff-quando-um-empregado-muda-de-departamento-sai-ou-uma-gest%C3%A3o-encerra-transferindo-projeto

**Sem equivalente direto no FAI** (ideia nova; usa Agrupamentos/Eras RF34 e o histórico RF17). **Aba:** ação no perfil/departamento (`/handoff`).

## Critérios de aceite
- **RF36.CA01** CHEFE ou EMPRESA aciona "Gerar dossiê de transição" para um empregado (saída/transferência) ou para uma GESTÃO (RF25.CA05); a IA compila: projetos abertos por fase, tarefas pendentes e bloqueadas com prazos, sessões DECIA em andamento, decisões pendentes de revisão, contatos/fornecedores citados e um **resumo de contexto** por projeto ("onde parou, o que falta, riscos").
- **RF36.CA02** O dossiê é uma tarefa DOCUMENTO (PDF) + um projeto "Transição de [nome]" com as tarefas de encaminhamento, com a faísca ✦ e o rastro (RF29).
- **RF36.CA03** O sucessor é indicado e, ao aceitar, recebe a responsabilidade das tarefas/projetos (histórico registra a transferência; o antigo responsável fica como "anterior").
- **RF36.CA04** Sessões DECIA ativas notificam o grupo da troca de participante (RF9) e mantêm o histórico intacto.
- **RF36.CA05** O dossiê respeita visibilidade: itens PRIVADOS do empregado só entram com consentimento dele; a saída de um empregado nunca apaga tarefas usadas por outros (snapshot RF23).


## RF37: Registrar reuniões com a Ata Viva (transcrição ou gravação → ata como tarefa + tarefas de encaminhamento com responsável e prazo dentro do projeto)

https://trello.com/c/I8z01AoM/104-rf37-registrar-reuni%C3%B5es-com-a-ata-viva-transcri%C3%A7%C3%A3o-ou-grava%C3%A7%C3%A3o-%E2%86%92-ata-como-tarefa-tarefas-de-encaminhamento-com-respons%C3%A1vel-e-pra

**Equivalente no FAI:** RF13 artefatos automáticos (ata) + RF36 foto com manequim (captura do mundo real para dentro do sistema). **Aba:** ação "Nova reunião" na sessão DECIA ou no projeto (`/meetings/new`).

## Critérios de aceite
- **RF37.CA01** Inicio uma reunião ligada a uma sessão DECIA ou a um projeto; posso gravar áudio no navegador, subir um arquivo de áudio/vídeo ou colar a transcrição (ex.: do Teams/Meet).
- **RF37.CA02** A IA transcreve (quando áudio) e gera a **ata** estruturada: participantes, pauta, deliberações, encaminhamentos (o quê, quem, quando), divergências e pendências, classificando os trechos como no RF7.
- **RF37.CA03** A ata vira uma tarefa ATA/REGISTRO no projeto (fase sugerida) e cada encaminhamento vira uma **tarefa com responsável e prazo** já vinculada por dependência à ata; o usuário confirma antes de persistir.
- **RF37.CA04** A ata é publicada na sessão DECIA como mensagem com anexos (RF29) e entra no rastro de decisão; participantes recebem notificação para ratificar ou contestar em 48 h.
- **RF37.CA05** Consentimento de gravação registrado por participante; áudio é apagado após a transcrição por padrão (configurável pela EMPRESA), em conformidade com a LGPD.


## RF38: Aplicar a identidade visual do Work AI — ícones por tipo de tarefa, thumbnails automáticos, capa-mosaico de projeto, fio de decisão, lacres, etiquetas de estado, temas e skins da Mesa

https://trello.com/c/LvMBvGkU/105-rf38-aplicar-a-identidade-visual-do-work-ai-%C3%ADcones-por-tipo-de-tarefa-thumbnails-autom%C3%A1ticos-capa-mosaico-de-projeto-fio-de-deci

**Equivalente no FAI:** anatomia dos cards (v17), anatomia do DNA, Background Studio (RF11), skins de card, temas (RF23 preferências). Detalhamento no card "WORK AI — Identidade visual e estética".

## Critérios de aceite
- **RF38.CA01** Cada tipo de tarefa tem ícone e cor próprios (tabela do card de identidade visual); o ícone aparece em cards, listas, busca, anexos de mensagem e no fio de decisão.
- **RF38.CA02** Toda tarefa recebe um **thumbnail automático** no upload/criação (1ª página estilizada, mini-gráfico, silhueta do desenho, monograma, favicon+captura), gerado de forma assíncrona; o usuário pode substituir por imagem manual ou pedir uma capa à IA.
- **RF38.CA03** A capa do projeto é um **mosaico 2×3** dos thumbnails das tarefas principais com anel de progresso por fase e borda na cor do departamento; atualiza quando as tarefas mudam.
- **RF38.CA04** Tudo gerado por IA exibe a **faísca ✦ âmbar** e um tooltip "gerado por IA em [data], revisado por [pessoa]" (transparência).
- **RF38.CA05** Estados são etiquetas de protocolo com o **nome do estado em texto** (acessibilidade) e estilo próprio (tracejado, pulso, cadeado, carimbo, estrela); prazos ficam âmbar a 3 dias e vermelho vencidos; prazo legal tem o ícone ⚖.
- **RF38.CA06** Chancela = lacre (dourado empresa / azul-marinho chefe); reconhecimento = medalha; decisão = carimbo VALIDADO/DEVOLVIDO com data e revisor.
- **RF38.CA07** Fio de decisão (RF29) renderizado como linha vertical com nós coloridos por classificação (argumento azul, divergência laranja, risco vermelho, consenso verde, pergunta roxa).
- **RF38.CA08** Temas claro, escuro, alto contraste e **Blueprint**; skins da Mesa de Trabalho (papel, cortiça, blueprint) salvas em `user_preferences`; layout responsivo com menu recolhível.
- **RF38.CA09** Cada departamento tem monograma + cor e a empresa tem logo; a cor do departamento aparece na borda dos seus itens.
- **RF38.CA10** Micro-interações: encaixe animado ao arrastar tarefa para a fase, confete discreto na decisão validada, faísca animada durante geração, empty states ilustrados; todas respeitam `prefers-reduced-motion`.


## RF39: Criar chancelas (EMPRESA / CHEFE DE DEPARTAMENTO) e concedê-las a tarefas, projetos e planos por vínculo sugerido pela IA, por política de critérios ou por premiação; habilitar benefícios resgatáveis

https://trello.com/c/5qnmmRgz/127-rf39-criar-chancelas-empresa-chefe-de-departamento-e-conced%C3%AA-las-a-tarefas-projetos-e-planos-por-v%C3%ADnculo-sugerido-pela-ia-por-po

**Equivalente no FAI:** RF20/RF21 Vínculo com marca/celebridade (SealBond Matcher, revisão opcional, tiers) + RF25 Selos/promoções + RF38 Cupons. Detalhamento no card "WORK AI — Chancelas". **Abas:** Minhas Chancelas (`/seals`), Criador de Chancela (página da empresa/departamento), Benefícios (`/benefits`).

## Entidades
- **Chancela** (= Seal): emissor (EMPRESA|CHEFE), nome, tier (TAREFA|PROJETO|PLANO), política de concessão (JSON: critérios + modo AUTO|REVISÃO), status, arte do lacre, `excelencia` (= premium), ciclo (`availableFrom/Until`), limite de emissões, `autoIssued`.
- **VínculoChancela** (= SealBond): item (tarefa/projeto/plano) × emissor; `basis` (MODELO_MATCH, DEPARTAMENTO_MATCH, PLANO_MATCH, DECISÃO_MATCH, POLÍTICA, INDICAÇÃO, PREMIAÇÃO); confiança; justificativa; status SUGERIDA → ACEITA/EDITADA/RECUSADA → EM_REVISÃO → APROVADA/REJEITADA; `requiresReview`; consentimento do autor; `aiInferenceId`.
- **Benefício** (= Promotion) e **Resgate** (= PromotionRedemption / CouponRight).

## Critérios de aceite
- **RF39.CA01** Só EMPRESA e CHEFE DE DEPARTAMENTO (ou CURADOR nomeado por eles, em nome do emissor) criam/editam chancelas; EMPREGADO recebe 403 ACESSO_NEGADO na API e não vê o criador.
- **RF39.CA02** O criador de chancela tem nome, tier, arte do lacre (catálogo + upload), ciclo, limite de emissões, flag Excelência e a **política de concessão** com critérios selecionáveis: conformidade ≥ X% (RF32), rastro completo (RF29), prazo cumprido, ≥ N reações BEM FUNDAMENTADO/CONFORME (RF26), ≥ N reutilizações (RF23), decisão validada (RF15), sem pendência ⛔; e o modo AUTO ou REVISÃO. Janela invertida é recusada (400 PERIODO_INVALIDO).
- **RF39.CA03 (por vínculo)** Ao publicar um projeto/tarefa, a IA sugere até 3 chancelas com confiança e justificativa (base: modelos chancelados usados, tarefas de membros do departamento, eixo do plano, decisão DECIA do departamento). O autor aceita, edita (troca tier/itens) ou recusa; recusadas ficam em "Minhas Chancelas › Recusadas" para aplicação posterior.
- **RF39.CA04 (por política)** A IA reavalia os critérios da política a cada evento relevante (nova reação, conformidade recalculada, decisão validada). Critérios atendidos + modo AUTO ⇒ emissão automática (`autoIssued`); modo REVISÃO ⇒ fila do chefe com o relatório de critérios.
- **RF39.CA05 (por premiação)** Chancela de Excelência só é concedida por curadoria (chefe/empresa/curador) a partir dos Destaques (RF35) e das indicações, dentro do ciclo e do limite; esgotado o limite, novas concessões são recusadas (409 LIMITE_ESGOTADO).
- **RF39.CA06** Empregado pode **indicar** item de colega (basis INDICAÇÃO → fila) e **propor** uma chancela nova ao chefe; nenhuma das ações emite chancela por si.
- **RF39.CA07** Emissão exige **consentimento do autor** (exibir lacre e virar MODELO OFICIAL); sem consentimento a chancela fica APROVADA_PRIVADA (conta para métricas, não aparece).
- **RF39.CA08** 1 chancela por par item/emissor; múltiplas chancelas de emissores distintos no mesmo item; revogação com motivo e expiração ao fim do ciclo ou quando a **recertificação** falha (critério deixa de valer); tudo em `audit_log` com correlationId.
- **RF39.CA09** O emissor publica **Benefícios** ligados à chancela: certificado PDF com QR, créditos de IA extras, pontos bônus, publicação direta na Vitrine, prioridade na fila de revisão, vaga em capacitação; cada um com validade e limite por pessoa.
- **RF39.CA10** Só quem possui a chancela aprovada e vigente resgata o benefício (409 CHANCELA_INVALIDA caso contrário); o resgate é idempotente e transacional (sem resgate duplo); créditos de IA são lançados no ledger de cota.
- **RF39.CA11** Item chancelado exibe o lacre (RF38), vira MODELO_PÚBLICO oficial e entra na Vitrine/Balcão como "chancelado" (RF40); métricas do emissor: chancelas emitidas, pendentes, revogadas, benefícios resgatados, por período.
- **RF39.CA12** Notificações ao autor em cada mudança de estado do vínculo e ao emissor em cada pedido/indicação; i18n em todas as mensagens.


## RF40: Oferecer tarefas, projetos e kits como modelos no Balcão de Modelos (marketplace interno em DECIA Points, sem dinheiro) e reutilizá-los com crédito ao autor

https://trello.com/c/rcxdmCBb/128-rf40-oferecer-tarefas-projetos-e-kits-como-modelos-no-balc%C3%A3o-de-modelos-marketplace-interno-em-decia-points-sem-dinheiro-e-reuti

**Equivalente no FAI:** estado "À venda" da peça (RF4.CA8 / RF31), sub-aba "Peças à venda" do perfil, Arara do Desapego do Meu Quarto e o remix. O empregado comum **não emite chancela e não transaciona dinheiro**: ele oferece modelos dentro do app e recebe **DECIA Points (RF42)** e reputação. **Abas:** Balcão de Modelos (`/models`, também acessível pela Loja Work AI), sub-aba "Meus modelos oferecidos" no perfil (RF19).

## Critérios de aceite
- **RF40.CA01** Em qualquer tarefa, projeto ou kit meu, a ação **"Oferecer como modelo"** define: preço em DECIA Points (0 = grátis), licença (CÓPIA_LIVRE, ATRIBUIÇÃO, SOMENTE_LEITURA), descrição de uso, visibilidade (DEPARTAMENTO|EMPRESA|PÚBLICO) e período; o item passa ao estado OFERECIDO (= à venda) mantendo o estado de trabalho original.
- **RF40.CA02** O Balcão tem duas prateleiras: **Modelos chancelados** (oficiais, RF39) e **Modelos da comunidade** (oferecidos por empregados), com filtros por categoria, tipo, departamento, licença, preço e ordenação por remixes/reações/recentes.
- **RF40.CA03** Reutilizar (remixar) um modelo oferecido debita os DECIA Points do comprador e **credita o autor** no mesmo lançamento (ledger idempotente, RF42); modelos gratuitos creditam apenas a métrica de reutilização (RF23). Saldo insuficiente ⇒ 409 SALDO_INSUFICIENTE com mensagem clara e atalho para ganhar pontos no DECIA.
- **RF40.CA04** A cópia respeita a licença: SOMENTE_LEITURA permite apenas "Levar ao projeto" como referência (não editável); ATRIBUIÇÃO mantém o crédito visível e imutável; CÓPIA_LIVRE permite tudo.
- **RF40.CA05** **Balcão de repasse** (= Arara do Desapego): ao arquivar uma tarefa, o sistema oferece "repassar ao Balcão"; tarefas repassadas aparecem com etiqueta "repasse" e preço 0.
- **RF40.CA06** O perfil mostra "Meus modelos oferecidos" com contadores (visualizações, remixes, DECIA Points recebidos) e permite retirar a oferta a qualquer momento (cópias já feitas permanecem).
- **RF40.CA07** EMPRESA/CHEFE podem **destacar** um modelo da comunidade e convertê-lo em chancelado pelo fluxo do RF39 (indicação → chancela), preservando o crédito do autor.
- **RF40.CA08** Não existe transação financeira: nenhum campo de moeda real, nenhum gateway; toda "compra" é lançamento no ledger de DECIA Points com auditoria.


## RF41: Gerir o Acervo de Tarefas (inventário do usuário): estados, sub-filtros, ordenação, prazos legais, anexos & evidências e ações rápidas

https://trello.com/c/fzZ0vq5I/139-rf41-gerir-o-acervo-de-tarefas-invent%C3%A1rio-do-usu%C3%A1rio-estados-sub-filtros-ordena%C3%A7%C3%A3o-prazos-legais-anexos-evid%C3%AAncias-e-a%C3%A7%C3%B5es-r%C3%A1pid

**Equivalente no FAI:** Closet Digital (RF6) + RF31 Estados do acervo + RF12 Minhas Fotos + RF7 detalhe da peça. **Abas:** Acervo de Tarefas (`/tasks`), detalhe da tarefa (`/tasks/[id]`), Anexos & Evidências (`/attachments`). O Acervo é o **inventário** que alimenta os selects do Criador de Projetos (RF21) e os anexos das mensagens do DECIA (RF29). A criação de tarefas é o RF20.

## Estados (= estados do acervo)
RASCUNHO · DISPONÍVEL · EM_USO (em ≥1 projeto ativo) · CONCLUÍDA · BLOQUEADA (aguarda outra tarefa/pessoa) · ARQUIVADA · MODELO_PÚBLICO (reutilizável por outros) · OFERECIDA (no Balcão, RF40).

## Sub-filtros (= Todos / Favoritos / Disponível / Indisponível / À venda)
Todas · Favoritas · Disponíveis · Em uso · Bloqueadas · Concluídas · Modelos públicos · Chanceladas · Oferecidas. Filtros: categoria, tipo, processo, natureza, departamento, classificação de acesso, prazo (vencidas, 7 dias, 30 dias), origem (Windows, Google, Microsoft, e-mail, protocolo). Ordenação: recentes, mais usadas, menos usadas, nome, prazo, valor.

## Critérios de aceite
- **RF41.CA01** Dado um empregado autenticado, quando abre o Acervo, então vê a grade de cards (RF38) com contadores por sub-filtro, skeleton de carregamento, estado vazio ilustrado e "tentar de novo" em erro.
- **RF41.CA02** Dado uma tarefa, quando muda de estado, então a transição obedece à máquina RASCUNHO→DISPONÍVEL→EM_USO⇄BLOQUEADA→CONCLUÍDA→ARQUIVADA; EM_USO é automático ao entrar em projeto ativo e volta a DISPONÍVEL ao sair; MODELO_PÚBLICO só via chancela (RF39) ou publicação explícita; toda transição fica em `wardrobe_availability_log`-equivalente (`task_state_log`).
- **RF41.CA03** Dado o detalhe da tarefa, quando o abro, então vejo pré-visualização (documento/planilha/imagem/desenho 2D-3D), metadados do RF20, versões (para itens vinculados ao Google/Microsoft), projetos em que está em uso, fio de decisão (RF29), chancelas, interações (RF26) e histórico.
- **RF41.CA04** Dado uma categoria com prazo legal, quando o prazo se aproxima, então o card fica âmbar a 3 dias e vermelho vencido (ícone ⚖), a Prioridade do Dia (RF19) a sugere e uma notificação é enviada ao responsável.
- **RF41.CA05** Dado que excluo uma tarefa usada em projetos de outros, quando confirmo, então os projetos mantêm o snapshot (RF23) e os donos são avisados; tarefas vinculadas a decisões validadas não podem ser excluídas, só arquivadas.
- **RF41.CA06** Dado Anexos & Evidências, quando envio fotos de vistoria/obra, então elas guardam data, geolocalização opcional e vínculo a tarefas/projetos, e podem virar tarefas IMAGEM_EDITADA pelo Estúdio de Documento (RF20).
- **RF41.CA07** Dado o card da tarefa, quando uso as ações rápidas, então tenho: favoritar, duplicar, "Levar ao projeto" (abre o select de fase do RF21), "Compartilhar na sessão DECIA" (RF29), "Pedir chancela" (RF39), "Oferecer no Balcão" (RF40), arquivar/repassar.
- **RF41.CA08** Dado o perfil de outro usuário, quando abro o Acervo dele (RF19), então vejo apenas tarefas com visibilidade compatível e a ação "Levar ao meu acervo" (RF23) quando permitida; a API responde 403 para o resto.
- **RF41.CA09** Dado filtros e ordenação aplicados, quando compartilho a URL, então a mesma visão é restaurada (querystring), e a lista é paginada (20 por página) com i18n.


## RF42: Acumular DECIA Points por participação de qualidade no chat DECIA e usá-los em compras dentro do app (Loja Work AI: modelos do Balcão, créditos de IA, capas/skins, impulsos, kits)

https://trello.com/c/t0EVs5qI/141-rf42-acumular-decia-points-por-participa%C3%A7%C3%A3o-de-qualidade-no-chat-decia-e-us%C3%A1-los-em-compras-dentro-do-app-loja-work-ai-modelos-d

**Equivalente no FAI:** RF30 FAI Points + RF41 FAI Points em jogos e criações (ledger idempotente, regras em banco, tetos, cupons). **Abas:** DECIA Points (`/points`: saldo, extrato, regras), Loja Work AI (`/store`). Os DECIA Points **substituem** o nome "Pontos de Contribuição" em todos os RFs (RF35, RF39, RF40): é a única moeda do app, sem dinheiro real.

## Como se ganha (só por participar bem no DECIA)
| Evento na sessão DECIA | Pontos | Regra |
|---|---|---|
| Mensagem classificada pela IA como **ARGUMENTO com evidência** (RF7) — cita tarefa/fonte | +5 | teto 10 mensagens/dia por sessão |
| Mensagem classificada como **CONSENSO** que a IA confirma como convergência | +3 | |
| **Divergência resolvida** por resposta minha (RF10) | +8 | só quando a IA marca a divergência como resolvida |
| **Pergunta da IA** em ponto crítico respondida com evidência (RF16) | +4 | |
| **Tarefa/artefato compartilhado** na sessão (RF29) e usado no resumo/decisão | +6 | crédito ao autor do artefato |
| **Decisão final validada** (RF15) em sessão em que contribuí | +15 base × qualidade | multiplicador 0,5–2,0 pelo perfil deliberativo (objetivo 2) |
| Presença em sessão **encerrada** com resumo (RF17) | +2 | |
| Reação **BEM FUNDAMENTADO / CONFORME** recebida em mensagem ou tarefa (RF26) | +2 | teto 20/dia |
| **Ata Viva** ratificada (RF37) e encaminhamentos cumpridos | +3 / +5 | |
| Benefício de chancela "pontos bônus" resgatado (RF39) | valor do benefício | |

Não geram pontos: mensagens classificadas como ruído/fora do tema, auto-reações, sessões de teste, mensagens repetidas (similaridade > 90 %).

## Onde se gasta (Loja Work AI = compras dentro do app)
- **Balcão de Modelos** (RF40): tarefas, projetos e kits oferecidos por colegas (preço em DP; 0 = grátis).
- **Créditos de IA extras**: cota adicional de geração (TEXTO_IA, Autopiloto, Simulador, extração de desenhos) — o custo real fica em `ai_inference_log`.
- **Capas, skins e temas** (RF38): skins da Mesa (Blueprint premium, cortiça, papel timbrado), molduras de card, capas geradas por IA em lote.
- **Impulso no Mural**: destacar um projeto/decisão por 24 h na Vitrine (RF27).
- **Sessão DECIA com IA avançada**: abrir sessão com modelo de IA premium e resumo analítico estendido (RF11).
- **Kits de Processo chancelados** e certificado PDF personalizado (RF39).
- **Doar pontos** a um colega (reconhecimento entre pares) — limite mensal.

## Critérios de aceite
- **RF42.CA01** Dado um evento pontuável na sessão DECIA, quando a IA confirma a classificação/condição, então o ledger recebe **1 lançamento idempotente** (chave = tipo + id do evento + usuário) com valor, motivo, sessão e `correlationId`; reprocessar o evento não duplica pontos.
- **RF42.CA02** Dado os tetos e o multiplicador de qualidade, quando o lançamento é calculado, então as regras vêm de tabela versionada (`decia_points_rules`) editável por ADMIN/EMPRESA, com vigência; alterar a regra não altera lançamentos passados.
- **RF42.CA03** Dado a tela DECIA Points, quando a abro, então vejo saldo, extrato paginado (evento, sessão, pontos, data), regras vigentes em linguagem simples e o gráfico de evolução mensal; tudo i18n.
- **RF42.CA04** Dado a Loja Work AI, quando compro um item, então o débito é **transacional e atômico** (saldo insuficiente ⇒ 409 SALDO_INSUFICIENTE; item indisponível ⇒ 409 ITEM_INDISPONIVEL), o item é entregue (modelo copiado, cota creditada, skin liberada, impulso agendado) e o extrato mostra a compra.
- **RF42.CA05** Dado uma compra no Balcão (RF40), quando o débito ocorre, então o autor do modelo é **creditado** no mesmo lançamento (transferência), respeitando a licença.
- **RF42.CA06** Dado créditos de IA comprados, quando uso uma função de IA, então a cota comprada é consumida antes da cota mensal padrão e o card mostra a origem; sem cota, a função avisa e oferece a Loja.
- **RF42.CA07** Dado abuso detectado (mensagens repetidas, conluio de reações, sessões fictícias), quando a regra antifraude dispara, então os lançamentos ficam **suspensos** para revisão do chefe, que confirma ou estorna com motivo (auditado).
- **RF42.CA08** Dado o perfil (RF19), quando abro o perfil deliberativo, então vejo os DECIA Points por tipo de evento e por sessão, ligando a moeda ao objetivo 2 (clareza, evidências, consistência); o dashboard (RF18/RF28) mostra pontos por departamento e custo de IA comprado.
- **RF42.CA09** Dado a política da empresa, quando configurada, então pontos podem **expirar** (ex.: 12 meses) com aviso 30 dias antes, e a doação entre colegas respeita limite mensal e não gera pontos ao doador.
- **RF42.CA10** Nenhum campo de moeda real, nenhum gateway de pagamento; o RNF de auditoria (correlationId, sem dados sensíveis) vale para todo lançamento.


## RF43: Usar a IA do sistema — insights do Acervo e do Perfil, ranking de usuários, motor do DECIA e Autopilot para criar tarefas e sugerir novos projetos com custo, tempo, prazo e viabilidade (EVM, CPM, PERT, Monte Carlo, ROI, matriz de risco)

https://trello.com/c/3SKhDCb1/143-rf43-usar-a-ia-do-sistema-insights-do-acervo-e-do-perfil-ranking-de-usu%C3%A1rios-motor-do-decia-e-autopilot-para-criar-tarefas-e-sug

**Equivalente no FAI:** RF24 Usar a IA do sistema (motor de IA e serviços externos: Strategy + Chain of Responsibility primário → alternativa → motor local, `ai_inference_log`, circuit breaker, fallback) + sugestões do Copilot (RF10) + Inventory Score (RF29) + Hype Score. **Abas:** Insights (`/insights`: Acervo · Perfil · Equipe · Ranking · Projetos sugeridos), Autopilot (`/autopilot`, estende o RF30), painel "IA do sistema" no admin (RF18).

## 1. Motor de IA (base de tudo)
- **AiEngine** com Strategy + Chain: provedor primário (Claude/Gemini) → alternativo → **motor local** (regras, embeddings locais, heurísticas de PM); circuit breaker, retry, timeout; **cota** por usuário/departamento (padrão mensal + créditos comprados com DECIA Points, RF42); feature flag por função.
- **Privacidade:** tarefas RESTRITO/SIGILOSO (RF20) nunca saem para provedor externo — só motor local, com aviso; dados pessoais mascarados antes da inferência (LGPD).
- **Transparência:** toda saída carrega a faísca ✦, "gerado por IA em [data] — modelo — revisado por", confiança e **explicação**; log completo em `ai_inference_log`.
- **Autoridade humana:** nada da IA vira decisão, chancela, ranking oficial ou projeto sem confirmação de uma pessoa.
- **Regra de ouro:** a IA **só interpreta métricas calculadas pelo sistema** (seção 8) — nunca inventa números.

## 2. Insights do Acervo (= IA do closet / Inventory Score)
**Score do Acervo** (0–100: completude de metadados, prazos em dia, reutilização, conformidade); tarefas **paradas**, **duplicadas** (similaridade), **lacunas por processo** ("seus projetos de Licitação nunca têm ETP"), **tarefas fantasma**, prazos legais em risco, **modelos recomendados** do Balcão; ações em 1 clique (arquivar, repassar, criar faltante, mesclar).

## 3. Insights do Perfil (complementa o perfil deliberativo, RF19)
Temas em que a pessoa argumenta melhor, **competências demonstradas** com evidências (tarefas, projetos, sessões), evolução mensal de clareza/evidência/consistência, **recomendações de desenvolvimento**, comparação **anonimizada** com o departamento e "resumo profissional" exportável (com consentimento).

## 4. Insights da Equipe (chefe/empresa)
Saúde e desempenho do departamento pelas métricas de equipes de alto desempenho (seção 8-D): carga e balanceamento, gargalos, segurança psicológica (pesquisa anônima), rede de colaboração, bus factor, eNPS; recomendações acionáveis ("redistribuir 3 tarefas de X para Y", "abrir sessão DECIA sobre o gargalo Z").

## 5. Ranking de usuários (transparente e opcional)
Por departamento/empresa/período, em dimensões separadas: Qualidade deliberativa (objetivo 2), DECIA Points (RF42), Reutilização (RF23/RF40), Rastro & conformidade (RF29/RF32), Pontualidade (SPI), Hype Score de Eficiência médio (RF44). Critérios e pesos **públicos**, editáveis pela EMPRESA; opt-out do ranking público; "**Explique minha posição**"; nunca ordena por volume bruto de mensagens.

## 6. IA do DECIA (motor compartilhado das sessões)
RF7/RF8/RF11/RF12/RF13/RF16 + citações da Memória Institucional (RF33) no mesmo AiEngine, em modo **Economia** (local + provedor barato) ou **Avançado** (premium; custa DECIA Points ou cota). Dentro da sessão a IA traz métricas reais ("este projeto está com SPI 0,82 e CPI 0,95") e projetos/tarefas relacionados.

## 7. Autopilot de Tarefas e de Projetos (estende o RF30)
**Tarefas:** a partir de e-mails, protocolos, atas (RF37), decisões (RF29) ou frase → tarefas em lote como rascunho (tipo, categoria, prazo legal, responsável, dependências), recorrências e kits.
**Projetos:** sugere novos projetos (eixos do plano sem projeto, lacunas, decisões sem projeto, metas, histórico) com **Ficha de Viabilidade** → tarefa ESTUDO_TECNICO_PRELIMINAR:
| Dimensão | Método / métrica |
|---|---|
| **Custo** | estimativa paramétrica + análoga com faixa P10/P50/P90; orçamento por WBS; **EVM** (PV, EV, AC, CPI, SPI, EAC, ETC, VAC) em execução; fontes: planilhas do acervo, projetos semelhantes (RF33), SINAPI/SICRO quando disponíveis |
| **Tempo** | **PERT** (O/M/P) por tarefa, **CPM** (caminho crítico, folgas), lead/cycle time históricos |
| **Prazo** | calendário de dias úteis + prazos legais; marcos por fase; **Monte Carlo** (1.000 execuções) → probabilidade de cumprir a data |
| **Viabilidade** | score 0–100: técnica, jurídica/conformidade (RF32), orçamentária, prazo (Monte Carlo), **risco** (matriz P×I, top 5 com resposta), **ROI/payback/VPL**, alinhamento ao plano (RF24), critérios SMART |
| **Organização** | **WBS**, **RACI**, burndown previsto |
A ficha mostra premissas, intervalos e o que a IA **não** sabe; aceitar → projeto RASCUNHO (RF21) ou sessão DECIA (RF29); descartar exige motivo.

## 8. Catálogo de métricas reais por domínio (base obrigatória dos insights)
Cada métrica tem fórmula documentada, fonte no sistema e "proxy" declarado quando o dado é indireto. A IA cita a métrica e o valor em todo insight.
**A. Inovação e empreendedorismo** — Innovation Accounting/Lean Startup (Ries): nº de hipóteses testadas e **taxa de validação** (projetos com fase de teste/piloto), **velocidade de aprendizado** (ciclos construir-medir-aprender por trimestre), **taxa de pivô**; Stage-Gate (Cooper): conversão por gate (DEMANDA→PLANEJAMENTO→…→EXECUÇÃO) e **time-to-market** (DEMANDA→EXECUÇÃO); **TRL** (nível de maturidade tecnológica) para projetos técnicos; % de projetos com componente inovador (categoria/tag) e **funil de inovação** (ideias → pilotos → escala); OKR: % de key results com progresso; Business/Lean Canvas preenchido (completude); **burn rate e runway** do orçamento do programa (RF25).
**B. Gestão de TI** — ITIL 4: **SLA/SLO** de resposta a demandas (protocolos/ofícios), taxa de incidentes e **MTTR** em serviços/sistemas citados nas tarefas, taxa de sucesso de mudanças; **DORA** (para projetos de software/TI da empresa): frequência de entrega, lead time de mudança, taxa de falha, tempo de restauração; COBIT: cobertura de controles (conformidade RF32); **TCO** e custo de IA por função/departamento (`ai_inference_log`); disponibilidade dos sistemas integrados (Google/Microsoft/e-Protocolo); **dívida técnica** = tarefas de TI adiadas (ADIEI) × idade; backlog aging.
**C. Gestão de projetos** — PMBOK/EVM: PV, EV, AC, **CPI, SPI**, EAC, ETC, VAC, TCPI; **CPM** e folgas; **PERT**; Monte Carlo; matriz de riscos e exposição (Σ P×I); Ágil/Kanban: **velocity**, **burndown/burnup**, **lead time, cycle time, throughput**, WIP e **Little's Law** (WIP = throughput × cycle time), **fluxo cumulativo**; PRINCE2: tolerâncias de prazo/custo estouradas; qualidade: **retrabalho** (tarefas devolvidas/reabertas) e first-time-right; **taxa de decisões com rastro** (RF29); % do plano anual coberto (RF24).
**D. Equipes de alto desempenho** — Projeto Aristotle (Google): **segurança psicológica** (pesquisa anônima de 7 itens, Edmondson), clareza de papéis (RACI preenchido), dependabilidade (prazos cumpridos); Lencioni: proxies para confiança/conflito/comprometimento (divergências resolvidas ÷ abertas, RF10); Tuckman: estágio da equipe por padrão de interação; Spotify **Team Health Check** (11 dimensões, trimestral); **eNPS**; Gallup Q12 (resumido); **balanceamento de carga** (desvio-padrão de tarefas ativas por pessoa; utilização ≤ 80 %); **bus factor** (pessoas únicas responsáveis por tarefas críticas); **rede de colaboração** (centralidade/pontes entre departamentos a partir de coautoria e sessões); tempo de resposta em sessões; **taxa de reconhecimento** (RF35); rotatividade e dossiês de transição (RF36).

## Critérios de aceite
- **RF43.CA01** Falha/timeout do provedor primário → alternativo → motor local, com aviso de fallback e log completo (modelo, custo, latência, correlationId).
- **RF43.CA02** Tarefa RESTRITO/SIGILOSO → só motor local, com aviso; dados pessoais mascarados em qualquer chamada externa.
- **RF43.CA03** Insights › Acervo mostra o Score com decomposição, listas (paradas, duplicadas, fantasma, lacunas), modelos recomendados, ação em 1 clique e explicação.
- **RF43.CA04** Insights › Perfil (só o dono) mostra competências com evidências, evolução mensal, recomendações e comparação anonimizada; resumo profissional só com consentimento explícito.
- **RF43.CA05** Ranking com dimensões separadas, período, critérios e pesos públicos, "Explique minha posição" e opt-out; pesos editados pela EMPRESA com vigência e auditoria; volume bruto de mensagens nunca é critério.
- **RF43.CA06** Sessão DECIA em modo Avançado cita fontes (RF33), traz métricas reais do projeto e sugere itens relacionados; custo debitado da cota ou dos DECIA Points com aviso prévio.
- **RF43.CA07** Autopilot de Tarefas devolve N tarefas em rascunho (tipo, categoria, prazo legal, responsável, dependências); nada vira DISPONÍVEL sem revisão (RF20).
- **RF43.CA08** Autopilot de Projetos devolve até 5 candidatos ordenados por viabilidade, cada um com Ficha de Viabilidade completa (custo P10/P50/P90, PERT/CPM, Monte Carlo, score decomposto, top 5 riscos, WBS, RACI) e premissas.
- **RF43.CA09** Projeto em execução mostra EVM (PV, EV, AC, CPI, SPI, EAC, ETC, VAC, TCPI), caminho crítico, burndown/fluxo cumulativo e alertas ("SPI < 0,9 há 2 semanas") com recomendação e link para o Simulador (RF31).
- **RF43.CA10** Aceitar a ficha cria projeto RASCUNHO (RF21) com tarefas/kits pré-selecionados e a ficha como ESTUDO_TECNICO_PRELIMINAR (✦), ou abre sessão DECIA (RF29); descartar exige motivo, que alimenta as próximas sugestões.
- **RF43.CA11** Sem chave externa, os cálculos determinísticos (PERT, CPM, Monte Carlo, EVM, scores, todas as métricas da seção 8) funcionam integralmente; só a redação fica simplificada, com aviso.
- **RF43.CA12** Painel admin "IA do sistema" mostra custo/latência por função e departamento, taxa de fallback, taxa de aceitação de sugestões, cotas e alertas de custo.
- **RF43.CA13** Toda métrica do catálogo é calculada por serviço de domínio testável, com fórmula, fonte e proxy documentados em `docs/arquitetura/METRICAS_GESTAO.md`; a IA só interpreta números calculados pelo sistema e cita a métrica no texto do insight.
- **RF43.CA14** Insights › Equipe (CHEFE/EMPRESA) mostra as métricas D com tendência, benchmarks internos (outros departamentos, anonimizados) e recomendações acionáveis; pesquisas (segurança psicológica, Health Check, eNPS) são anônimas, com mínimo de 5 respondentes para exibir resultado.
- **RF43.CA15** Insights de inovação e TI (A e B) só aparecem quando há dados suficientes (mínimo de 3 projetos/sinais); caso contrário a tela explica o que falta coletar em vez de mostrar números vazios.


## RF44: Receber a Tarefa do Dia sugerida pela IA e acompanhar o Hype Score de Eficiência (previsto × realizado), calculado por princípios de gestão empresarial e de projetos, com feedback diário e semana planejada

https://trello.com/c/86403c3G/145-rf44-receber-a-tarefa-do-dia-sugerida-pela-ia-e-acompanhar-o-hype-score-de-efici%C3%AAncia-previsto-%C3%97-realizado-calculado-por-princ%C3%ADp

**Equivalente no FAI:** Look do Dia (DailyLook: 1 por dia, índice único usuário+data, **Hype Score**, feedback ADOREI / NAO_USEI / NAO_GOSTEI) + WeekPlan. **Aba:** sub-aba "Tarefa do Dia" no perfil (RF19) e widget no topo do Acervo (RF41) e da Mesa (RF22).

## 1. Escolha da Tarefa do Dia (priorização por teoria de gestão)
A IA (RF43) escolhe, entre as tarefas DISPONÍVEIS/EM_USO do usuário, a tarefa do dia por um **índice de prioridade** transparente:
- **Matriz de Eisenhower** — urgência (dias até o prazo/prazo legal) × importância (eixo do plano anual RF24, decisão DECIA pendente RF29, chancela pedida);
- **WSJF** (SAFe) = Custo do Atraso ÷ Tamanho do trabalho (Porte P/M/G, RF20) — custo do atraso = valor envolvido + risco de prazo legal + nº de tarefas de colegas que ela desbloqueia;
- **Folga no CPM** (PMBOK): tarefas no caminho crítico de um projeto ativo sobem;
- **MoSCoW** do projeto (Must/Should) e **Pareto**: as 20 % de tarefas que geram 80 % do avanço;
- **WIP/Little's Law**: se o usuário já tem WIP acima do limite, a IA sugere **concluir** algo em vez de começar.
O usuário pode trocar por outra tarefa (a IA registra o motivo para aprender).

## 2. Hype Score de Eficiência (HSE, 0–100)
Calculado **antes** (previsto) e **depois** (realizado) do dia, com cada componente explicado e sua base teórica:
| Componente | Peso | Cálculo | Base |
|---|---|---|---|
| **Eficiência** | 20 | esforço real ÷ esforço estimado (PERT M) — ≤ 1,0 → 100; 1,5 → 50; ≥ 2 → 0 | Drucker (fazer certo as coisas); PMBOK estimativas |
| **Eficácia** | 20 | alinhamento: tarefa ligada a eixo do plano (+50), no caminho crítico (+30), com decisão DECIA pendente (+20) | Drucker (fazer as coisas certas); CPM |
| **Valor (WSJF)** | 15 | WSJF da tarefa normalizado entre as tarefas do usuário no dia | SAFe / custo do atraso (Reinertsen) |
| **Pontualidade** | 15 | SPI da tarefa = EV ÷ PV (concluída no prazo = 100; cada dia de atraso −10) | EVM (PMBOK) |
| **Qualidade** | 15 | first-time-right: sem devolução/retrabalho (+60), conformidade do Espelho ok (+20), reações BEM FUNDAMENTADO/CONFORME (+20) | Lean; Deming PDCA; ISO 9001 |
| **Impacto na equipe** | 10 | nº de tarefas de colegas desbloqueadas (throughput liberado) | Teoria das Restrições (Goldratt) |
| **Foco** | 5 | WIP ≤ limite pessoal e conclusão sem troca de contexto registrada | Kanban / Little's Law; Newport (trabalho profundo) |
HSE realizado alimenta: a média móvel de 7 dias no perfil (RF19), o ranking "Hype Score de Eficiência médio" (RF43) e os insights de equipe (balanceamento de carga).

## 3. Feedback do dia (= ADOREI / NAO_USEI / NAO_GOSTEI)
**CONCLUÍ** (registra esforço real em horas) · **ADIEI** (motivo: prioridade mudou / falta de tempo / dependência) · **BLOQUEADA** (por quem/o quê → cria dependência e notifica) · **DELEGUEI** (para quem → transfere responsável). O feedback ajusta a próxima sugestão (aprendizado por usuário) e o HSE realizado.

## 4. Semana planejada (= WeekPlan)
Visão de segunda a sexta com a tarefa do dia sugerida para cada dia (respeitando prazos legais, reuniões da agenda Google/Microsoft e carga ≤ 80 %); arrastar para reordenar; **streak** de dias com CONCLUÍ; "Sexta de fechamento" com o HSE da semana.

## Critérios de aceite
- **RF44.CA01** Dado um empregado com ≥1 tarefa DISPONÍVEL/EM_USO, quando abre o app após 6h, então vê a Tarefa do Dia (1 por dia, índice único usuário+data) com o índice de prioridade decomposto (Eisenhower, WSJF, folga, MoSCoW) e o HSE previsto explicado por componente.
- **RF44.CA02** Dado a sugestão, quando troco por outra tarefa, então o sistema pede o motivo (lista + texto), registra e ajusta os pesos do usuário para os próximos dias.
- **RF44.CA03** Dado o feedback CONCLUÍ com esforço real, quando salvo, então o HSE realizado é calculado com a tabela da seção 2, comparado ao previsto (▲▼) e persistido; a tarefa passa a CONCLUÍDA (RF41) e as tarefas dependentes são notificadas.
- **RF44.CA04** Dado ADIEI/BLOQUEADA/DELEGUEI, quando salvo, então o HSE do dia recebe apenas os componentes aplicáveis (sem penalizar bloqueio causado por terceiro, que é atribuído ao insight de equipe), e a dependência/transferência é criada com rastro.
- **RF44.CA05** Dado usuário com WIP acima do limite pessoal (padrão 3), quando a IA escolhe, então prioriza concluir uma tarefa EM_USO e explica ("Little's Law: seu cycle time subiu 40 % com 5 tarefas em paralelo").
- **RF44.CA06** Dado a Semana planejada, quando a abro, então vejo 5 sugestões com prazos legais, reuniões e carga considerados; reordenar por arrastar persiste; o fechamento de sexta mostra HSE médio, streak e 1 recomendação.
- **RF44.CA07** Dado o perfil (RF19), quando abro a sub-aba Tarefa do Dia, então vejo histórico dos últimos 30 dias (tarefa, feedback, HSE previsto × realizado), média móvel de 7 dias e gráfico de componentes.
- **RF44.CA08** Todas as fórmulas do HSE e do índice de prioridade são calculadas por serviço de domínio testável, com pesos versionados por EMPRESA (tabela `hse_weights`) e documentadas em `docs/arquitetura/METRICAS_GESTAO.md`; mudança de pesos não recalcula dias passados.
- **RF44.CA09** A escolha da tarefa e o texto explicativo carregam a faísca ✦ e o log em `ai_inference_log`; sem IA externa, o motor local calcula tudo (determinístico) e só a redação fica simplificada.
- **RF44.CA10** Notificação diária opcional (RF3 preferências) às 8h no fuso do usuário com a Tarefa do Dia; i18n em todas as mensagens.


## RF45: Calcular com a IA o Hype Score do Perfil (0–1000) a partir de tudo o que o usuário produziu, das interações recebidas (curtidas, reações, comentários, salvos, remixes) e da participação no DECIA — exibível ou oculto a critério do usuário, sempre explicável

https://trello.com/c/Fs2RtK6q/147-rf45-calcular-com-a-ia-o-hype-score-do-perfil-0-1000-a-partir-de-tudo-o-que-o-usu%C3%A1rio-produziu-das-intera%C3%A7%C3%B5es-recebidas-curtidas

**Equivalente no FAI:** Hype Score do look/perfil (RF6 painel do Look do Dia) + Inventory Score (RF29) + contadores sociais (RF19) — aqui consolidados em um **índice de reputação profissional** por pessoa. **Aba:** cabeçalho do perfil (RF19) com o selo do Hype Score (se exibido), página `/profile/hype` (só o dono) com a decomposição.

## 1. O que entra no cálculo (5 blocos, 0–1000)
| Bloco | Peso | Entradas (todas calculadas pelo sistema, RF43 seção 8) |
|---|---|---|
| **Produção** | 25 % | tarefas, projetos, planos e kits criados, ponderados por completude de metadados, estado (CONCLUÍDA/APROVADO valem mais que RASCUNHO), chancela (RF39) e conformidade (RF32); Score do Acervo (RF43) |
| **Reconhecimento social** | 25 % | curtidas, reações qualitativas (ÚTIL / BEM FUNDAMENTADO / INOVADOR / CONFORME — as duas últimas pesam mais), comentários recebidos (com resposta = engajamento), salvos, compartilhamentos e **remixes** (RF26/RF40); cada interação é ponderada pela **reputação de quem interage** (estilo PageRank: a curtida de um chefe ou de alguém com Hype alto vale mais) |
| **Participação no DECIA** | 25 % | DECIA Points (RF42), argumentos com evidência, divergências resolvidas, decisões validadas em que contribuiu, presença em sessões encerradas, consistência entre sessões (perfil deliberativo, objetivo 2) |
| **Eficiência e impacto** | 15 % | Hype Score de Eficiência médio (RF44), pontualidade (SPI), reutilizações das suas tarefas por outros (RF23), tarefas de colegas desbloqueadas |
| **Reconhecimentos e chancelas** | 10 % | reconhecimentos e medalhas (RF35), chancelas recebidas (tier PROJETO/PLANO valem mais, Excelência vale o dobro), destaques do mês |

## 2. Regras estatísticas (para ser justo e à prova de manipulação)
- **Média bayesiana** em cada bloco (evita que 2 curtidas em 1 tarefa deem nota máxima); **decaimento temporal** com meia-vida de 180 dias (produção antiga conta menos, mas nunca zera); **normalização por departamento/empresa** (percentil) para comparar contextos diferentes; **teto por dia** em cada tipo de evento e **antifraude** compartilhado com o RF42 (auto-interação, conluio de reações, mensagens repetidas não contam); só interações **de pessoas verificadas** (perfil aprovado) entram.
- Faixas: 0–199 Iniciante · 200–399 Contribuinte · 400–599 Referência · 600–799 Líder de prática · 800–1000 Lenda do departamento (nomes editáveis pela EMPRESA).

## 3. Exibição (o usuário decide)
Opções: **PÚBLICO** (todos veem o número e a faixa), **EMPRESA** (só colegas da empresa), **SÓ EU** (padrão inicial). O score também pode aparecer, opcionalmente, nos cards de tarefa/projeto como "autor com Hype 640". Ocultar não impede o cálculo nem o uso no ranking (RF43), que respeita o opt-out próprio do ranking.

## 4. Explicabilidade e uso permitido
"**Por que meu Hype é 640?**": decomposição por bloco, top 5 eventos que mais contribuíram no período, o que mais derrubou, e 3 sugestões concretas para subir. A IA redige o texto sobre números do sistema (nunca inventa). O score é **indicador de reputação e desenvolvimento**, não instrumento disciplinar: a EMPRESA registra na política de uso (LGPD) que ele não substitui avaliação de desempenho formal.

## Critérios de aceite
- **RF45.CA01** Dado um usuário com atividade, quando o job diário (e sob demanda) recalcula, então o Hype Score do Perfil (0–1000) é persistido com data, versão dos pesos e a decomposição por bloco; recalcular o mesmo dia é idempotente.
- **RF45.CA02** Dado a fórmula, quando um bloco tem poucas amostras, então a média bayesiana puxa para a média do departamento e a tela informa "amostra pequena"; o decaimento temporal (meia-vida 180 dias) é aplicado a todos os eventos.
- **RF45.CA03** Dado uma interação recebida, quando ela vem de perfil não verificado, de auto-interação ou de padrão marcado pelo antifraude (RF42), então ela não entra no cálculo e fica visível na aba "ignoradas" do dono, com o motivo.
- **RF45.CA04** Dado a ponderação por reputação de quem interage, quando o job roda, então o peso de cada interação é derivado do Hype do autor da interação no mês anterior (evita ciclos), limitado a 3× o peso base.
- **RF45.CA05** Dado a página `/profile/hype` (só o dono), quando a abro, então vejo o score, a faixa, a decomposição por bloco, o histórico mensal (12 meses), o top 5 de eventos positivos e negativos e 3 sugestões, com faísca ✦ no texto e log em `ai_inference_log`.
- **RF45.CA06** Dado as preferências (RF3), quando escolho PÚBLICO / EMPRESA / SÓ EU, então o cabeçalho do perfil (RF19) e os cards de autoria respeitam a escolha imediatamente; a API nunca retorna o score a quem não tem permissão (403/omissão do campo).
- **RF45.CA07** Dado a EMPRESA, quando edita pesos dos blocos, meia-vida ou nomes das faixas, então a alteração tem vigência futura, fica auditada e não recalcula meses passados; pesos e regras são públicos na página "Como o Hype é calculado".
- **RF45.CA08** Dado o ranking (RF43), quando usa o Hype do Perfil como dimensão, então respeita o opt-out do ranking e nunca expõe o número de quem escolheu SÓ EU.
- **RF45.CA09** Todos os cálculos são feitos por serviço de domínio testável, documentados em `docs/arquitetura/METRICAS_GESTAO.md` (seção Hype do Perfil), com testes unitários para média bayesiana, decaimento, normalização e antifraude; a IA só redige a explicação.
- **RF45.CA10** Dado o dashboard (RF18/RF28), quando consultado por EMPRESA/CHEFE, então mostra a distribuição de Hype por departamento (histograma, anonimizado) e a evolução média, nunca a lista nominal de quem ocultou.


## RF46: Utilizar chats de mensageria para comunicar-se com outros usuários e atribuir ou receber tarefas e projetos

https://trello.com/c/IVrvZvpO/152-rf46-utilizar-chats-de-mensageria-para-comunicar-se-com-outros-usu%C3%A1rios-e-atribuir-ou-receber-tarefas-e-projetos

*O cartão ativo não tem descrição; critérios derivados locais continuam sujeitos à confirmação de produto.*

## RF47: Encontrar palavras-chave em documentos — varrer documentos longos de tarefas e projetos para localizar e extrair termos, frases e palavras (com contexto e fonte)

https://trello.com/c/Z4umYwGm/200-rf47-encontrar-palavras-chave-em-documentos-varrer-documentos-longos-de-tarefas-e-projetos-para-localizar-e-extrair-termos-frase

**Equivalente no FAI:** — (sem equivalente; nasce do trabalho com documentos longos no setor público: editais, contratos, TRs, pareceres, atas). **Aba:** Encontrar (`/find`; também como botão "Encontrar neste documento" dentro de uma tarefa ou projeto). Complementa o Buscar (RF27, que acha *itens*), a Memória Institucional (RF33, busca semântica) e a detecção de palavras-chave do Criador de Tarefas (RF20.CA02): aqui o foco é **dentro do texto** dos anexos.

**Modos:** (1) **Encontrar palavra-chave em documento** — escolho uma tarefa/projeto (ou vários) e procuro termos; (2) **Só encontrar palavra-chave** — procuro em todos os documentos que posso ver.

**Interface escolhida (2026-10-06): Opção A + Opção C.** A = tela principal de busca com palavra no contexto (KWIC); C = aba "Extrair termos e entidades" na mesma tela. As duas também existem dentro do RF48 (dossiê da contratação).

**Base:** recuperação de informação clássica, sem depender de IA — índice invertido com ranking BM25 e analisador em português (stemming RSLP, stopwords, sem acento) [Manning, Raghavan & Schütze, *Introduction to Information Retrieval*, 2008; Orengo & Huyck, 2001]; concordância KWIC (palavra no contexto) [Luhn, 1960]; extração automática de termos-chave sem treino (YAKE!) [Campos et al., 2020]. A IA é opcional (resumo dos achados) e passa pelo gate do RF43.

## Critérios de aceite
- **RF47.CA01** Dado um usuário autenticado na aba Encontrar, quando informa um ou mais termos (com operadores: frase exata entre aspas, E/OU/NÃO, curinga `*`, proximidade "termo1 termo2"~N) e o escopo (uma tarefa, um projeto, uma seleção ou "tudo que posso ver"), então recebe a lista de ocorrências agrupada por documento, com contagem, página/seção e **trecho em contexto** (KWIC, ±N palavras) com o termo destacado.
- **RF47.CA02** Dado o escopo, quando a busca roda, então **só entram documentos que o usuário pode ver** (mesma política de acesso do Bloco 5: dono, colaboradores, visibilidade, departamento); documento invisível nunca aparece nem é contado.
- **RF47.CA03** Dado um documento PDF, DOCX, XLSX, PPTX, TXT, MD, CSV, EML/MSG ou imagem/PDF digitalizado, quando é anexado, então o texto é extraído (com OCR quando não há camada de texto) e indexado em segundo plano; enquanto não indexa, o documento aparece como "em processamento" e a busca avisa que ele ficou de fora.
- **RF47.CA04** Dado "Extrair termos" sobre um documento ou projeto, quando acionado, então o sistema lista os **termos e frases-chave** mais relevantes (YAKE!/TF-IDF) com frequência e onde ocorrem, e as **entidades** reconhecidas por padrão: CNPJ/CPF (mascarados conforme LGPD), valores em R$, datas e prazos, números de processo/protocolo, artigos de lei citados ("art. 75 da Lei 14.133/2021"), e-mails e telefones (mascarados).
- **RF47.CA05** Dado um **glossário/lista de termos** salvo (ex.: "cláusulas de risco": multa, rescisão, reajuste, garantia, subcontratação), quando aplico a lista a um documento, então vejo quais termos aparecem, quais **não** aparecem e onde — útil para conferir cláusulas obrigatórias.
- **RF47.CA06** Dado o resultado, quando exporto, então baixo CSV/XLSX com termo, documento, página, trecho e link; e posso **salvar a busca** e **anexar o resultado como evidência** numa tarefa, projeto ou sessão DECIA (RF29), com o rastro de origem.
- **RF47.CA07** Dado um documento classificado RESTRITO ou SIGILOSO, quando é indexado ou resumido, então todo o processamento fica no servidor do Work Station (nunca vai a IA externa — RF43.CA02); o trecho em contexto respeita a classificação de quem vê.
- **RF47.CA08** Dado que a busca não acha nada, quando o resultado volta, então o sistema mostra variações tentadas (sem acento, radical) e sugere ampliar o escopo — sem inventar ocorrência.
- **RF47.CA09** Dado um documento longo (até o limite configurado, padrão 2 000 páginas), quando busco, então a resposta da busca vem em até 2 s para o primeiro lote (paginação dos demais), medida e registrada.
- **RF47.CA10** Dado qualquer busca ou extração, quando executada, então fica na trilha de auditoria (quem, quando, escopo e termos — sem guardar o conteúdo dos documentos no log).
- **RF47.CA11 (Opção A — tela principal)** Dado a aba Encontrar, quando busco, então os resultados aparecem como linhas KWIC alinhadas (referência da página · contexto à esquerda · **termo** ao centro · contexto à direita), com controle do tamanho do contexto (±4 / ±8 / ±16 palavras), alternância **agrupar por documento / por termo**, filtros laterais (documentos com contagem, classificação) e as ações exportar, salvar busca e anexar como evidência; cada linha abre o documento na posição da ocorrência.
- **RF47.CA12 (Opção C — aba Extrair)** Dado a aba "Extrair termos e entidades" da mesma tela, quando aberta para o escopo atual, então vejo abas **Termos e frases-chave** (relevância e ocorrências), **Valores (R$)**, **Datas e prazos**, **Artigos de lei citados** e **Órgãos, empresas e processos** (CPF/CNPJ mascarados), cada linha com "onde aparece" e **"Ver no contexto"**, que abre a Opção A já filtrada naquele termo; sem IA, com "Resumir com IA" opcional.
- **RF47.CA13** Dado o RF48 (aba Agentes), quando abro um dossiê de contratação, então as Opções A e C estão disponíveis com o escopo fixado nos documentos daquele dossiê (ver RF48.CA13–CA15).


## RF48: Utilizar a aba Agentes (Copilot de testes) para testar uma contratação antes do início e durante a execução — testes contratuais, orçamentários, comportamentais, de integridade e Score do Contrato, sempre com fundamentação bibliográfica

https://trello.com/c/uhSouFfk/201-rf48-utilizar-a-aba-agentes-copilot-de-testes-para-testar-uma-contrata%C3%A7%C3%A3o-antes-do-in%C3%ADcio-e-durante-a-execu%C3%A7%C3%A3o-testes-contratuai

**Equivalente no FAI:** — (sem equivalente). **Não é o Copilot sugestivo do RF26**: aqui o Copilot **testa**. Cada agente executa uma bateria de testes sobre o dossiê de uma contratação (tarefas e anexos do projeto: ETP, TR, edital, proposta, contrato, medições, aditivos, certidões) e devolve **achados verificáveis**, nunca uma decisão. **Aba:** Agentes (`/agents`; também "Testar esta contratação" dentro de um projeto de categoria Licitação/Contrato). Contexto: contratações do **Governo do Estado do Paraná** — Lei 14.133/2021, regulamentação estadual (Decreto Estadual 10.086/2022) e, para contratos antigos, Lei Estadual 15.608/2007.

**Regra de ouro (IA é crítica, não decisora):** todo achado traz evidência (trecho do documento, certidão ou consulta com data) **e** fundamentação normativa e bibliográfica real (artigo de lei, norma técnica, obra acadêmica ou profissional, com seção/página quando houver). Sem referência, não é achado.

**Encontrar e Extrair no dossiê (Opções A + C do RF47, escolhidas em 2026-10-06):** a mesa de testes traz "Encontrar no dossiê" (busca com palavra no contexto) e "Extrair do dossiê" (termos, valores, prazos, artigos de lei, entidades), com o escopo fixado nos documentos da contratação; a extração alimenta os testes e cada ocorrência pode virar evidência de um achado.

## Agentes (baterias de testes)
**Antes do início (fase preparatória e seleção)**
1. **Vale a pena contratar?** — necessidade, alternativas, fazer-ou-comprar, custo total. Base: art. 18 §1 (ETP); PMBOK 6ª ed. §12.1 (análise fazer-ou-comprar); Williamson, *The Economic Institutions of Capitalism* (1985, custos de transação). Abre decisão DECIA tipo CONTRATACAO (RF29).
2. **Orçamentário / preço** — estimativa, dispersão, sobrepreço, inexequibilidade. Base: art. 23; art. 59 §4 (obras < 75% do orçado); TCU, *Licitações & Contratos: Orientações e Jurisprudência*; estatística robusta (mediana, quartis).
3. **Contratual (cláusulas)** — cláusulas necessárias, garantias, reajuste/repactuação, sanções, subcontratação. Base: art. 92; arts. 96–102; art. 25 §§7–8; Justen Filho, *Comentários à Lei de Licitações e Contratações Administrativas*.
4. **Matriz de riscos** — alocação e lacunas. Base: art. 6 XXVII e art. 22; ISO 31000:2018; PMBOK 6ª ed. cap. 11.
5. **Habilitação e certidões** — validade e coerência (CND federal, FGTS, CNDT, estadual PR, municipal, falência). Base: arts. 62–70; art. 91 §4 (verificar regularidade e CEIS/CNEP antes de formalizar ou prorrogar).
6. **Econômico-financeiro** — índices do edital (LG, SG, LC, PL mínimo); indicadores auxiliares de solvência, **nunca critério de inabilitação**. Base: art. 69; Kanitz (1978, termômetro de insolvência); Altman (1968, Z-score).
7. **Integridade (ética e moral)** — sanções e impedimentos em fontes oficiais (CEIS/CNEP, CNIA/CNJ, inidôneos TCU, registros estaduais), quadro societário, programa de integridade. Base: Lei 12.846/2013; art. 25 §4 e art. 156; Decreto 11.129/2022 art. 57; ISO 37001:2016; CGU, *Programa de Integridade: Diretrizes para Empresas Privadas* (2015); OCDE, *Recommendation on Public Procurement* (2015).
8. **Capacidade técnica e competitividade** — parcelas de maior relevância, quantitativos, cláusulas restritivas. Base: art. 67 §§1–2; art. 9; Súmulas TCU 247 e 263.

**Durante a execução**
9. **Desempenho físico-financeiro (quantitativo)** — medido × previsto, CPI, SPI, EAC, curva S. Base: art. 117; ANSI/EIA-748; Fleming & Koppelman, *Earned Value Project Management*; PMBOK 6ª ed. §7.4.
10. **Aditivos e reequilíbrio** — limites de 25%/50%, justificativa e álea extraordinária. Base: arts. 124–125; Justen Filho.
11. **Prazos e vigência** — vencimentos, prorrogação, certidões a vencer. Base: arts. 105–107; art. 91 §4.
12. **Trabalhista e previdenciário** (mão de obra dedicada). Base: art. 50; art. 121 §§2–3; Súmula TST 331.
13. **Comportamental do contratado** — atrasos, notificações, ocorrências, reincidência, resposta a solicitações. Base: art. 88 §3 (avaliação de desempenho por indicadores objetivos no registro cadastral); Williamson (oportunismo); Kraljic, *Purchasing Must Become Supply Management* (HBR, 1983); Dickson (1966, critérios de seleção de fornecedores).
14. **Sanções e processo** — tipificação, dosimetria e contraditório. Base: arts. 155–163.
15. **Recebimento e encerramento** — provisório/definitivo e lições aprendidas (vão para a Memória Institucional, RF33). Base: art. 140; PMBOK (lições aprendidas).

**Transversais**
16. **Score do Contrato (0–100)** — por dimensão (Integridade, Regularidade, Saúde financeira, Conformidade contratual, Desempenho, Risco) e geral; soma ponderada transparente com a contribuição de cada dimensão. Base: Keeney & Raiffa, *Decisions with Multiple Objectives* (1976); art. 88 §3. Usa o motor de pontuação do DECIA.
17. **Contra-teste (pre-mortem)** — "imagine que este contrato fracassou: por quê?". Base: Klein, *Performing a Project Premortem* (HBR, 2007).

## Critérios de aceite
- **RF48.CA01** Dado um usuário com acesso ao projeto, quando abre a aba Agentes, então vê o catálogo por fase (antes do início / execução / transversais) com o que cada agente testa, a base normativa e a bibliografia, e pode rodar um agente, um grupo ou todos sobre o dossiê.
- **RF48.CA02** Dado um teste executado, quando termina, então o **Relatório de Testes** lista cada achado com: teste, resultado (✅ conforme · ⚠️ atenção · ⛔ não conforme · ❔ não verificável), **evidência** (documento e trecho, ou consulta externa com fonte, data e hora) e **fundamentação** (artigo e/ou referência bibliográfica real da base curada, com versão).
- **RF48.CA03** Dado qualquer achado sem evidência ou sem referência da base bibliográfica curada, quando o relatório é montado, então ele **não aparece como achado**; no máximo aparece em "Hipóteses não fundamentadas", rotulado assim e fora do Score.
- **RF48.CA04** Dado o papel do Copilot, quando ele responde, então **não sugere nem redige conteúdo** (isso é RF26/RF13), não aprova nem reprova empresa ou contrato e não emite parecer jurídico; o relatório traz "não substitui parecer jurídico nem a decisão da autoridade competente" e a decisão é humana, registrada (RF29).
- **RF48.CA05** Dado uma consulta externa (ex.: CEIS/CNEP pela API do Portal da Transparência, certidões), quando falha, expira ou exige verificação humana (captcha), então o teste fica ❔ **não verificado**, nunca ✅; cada consulta guarda fonte, data e hora e o hash da resposta.
- **RF48.CA06** Dado o agente de Integridade, quando roda, então usa **só fontes oficiais públicas**, descreve fatos ("sanção X registrada no CEIS em dd/mm/aaaa, vigente até…") sem juízo moral sobre pessoas, mascara dados pessoais (LGPD) e permite à área anexar contraditório ou justificativa ao achado.
- **RF48.CA07** Dado o Score do Contrato, quando calculado, então mostra o valor geral, cada dimensão, o peso e a contribuição de cada uma, e a confiança (proporção de testes verificáveis). **Portões não se compensam**: sanção impeditiva vigente, certidão obrigatória vencida ou ⛔ crítico marcam o contrato "bloqueado para verificação", qualquer que seja o número. Pesos versionados e definidos por EMPRESA/CHEFE.
- **RF48.CA08** Dado um contrato em execução, quando ocorre um gatilho (medição lançada, aditivo proposto, certidão a vencer em 15 dias, prorrogação ou ciclo mensal), então os agentes da fase rodam de novo e as mudanças desde a última execução aparecem destacadas.
- **RF48.CA09** Dado um dossiê com documento RESTRITO ou SIGILOSO, quando um agente usa IA, então o processamento é só local (RF43.CA02), com orçamento de IA (RF43) e registro em `ai_inference_log`; os testes determinísticos (prazos, limites, datas, índices) rodam sem IA.
- **RF48.CA10** Dado o relatório, quando exporto ou anexo, então gero PDF/XLSX com sumário, achados, evidências e bibliografia citada (ABNT NBR 6023), e posso anexá-lo como evidência no projeto, no processo (protocolo) ou numa sessão DECIA.
- **RF48.CA11** Dado o mesmo dossiê e a mesma versão das regras, quando reexecuto os testes determinísticos, então o resultado é idêntico (reprodutível); a versão das regras e da base bibliográfica fica no relatório e na trilha de auditoria.
- **RF48.CA12** Dado o perfil de quem roda (agente de contratação, gestor ou fiscal do contrato, controle interno, chefe), quando o catálogo abre, então os agentes recomendados para aquele papel vêm primeiro (art. 8, art. 117, art. 169); o acesso ao dossiê segue a política de autorização do Bloco 5.
- **RF48.CA13 (Opção A no dossiê)** Dado o dossiê aberto na aba Agentes, quando aciono **"Encontrar no dossiê"**, então uso a busca com palavra no contexto do RF47 (CA11) com o escopo fixado nos documentos da contratação; cada ocorrência tem **"Vincular como evidência"**, que a liga a um achado existente ou a uma verificação manual registrada no relatório.
- **RF48.CA14 (Opção C no dossiê)** Dado o dossiê, quando aciono **"Extrair do dossiê"**, então vejo a extração do RF47 (CA12) — termos, valores, datas e prazos, artigos de lei, órgãos/empresas/processos — e os agentes determinísticos a usam como entrada (ex.: Prazos e vigência lê as datas; Aditivos compara valores com o limite do art. 125; Contratual confere artigos citados); cada achado aponta a linha extraída e o trecho de origem.
- **RF48.CA15** Dado uma lista de termos do RF47 (ex.: "cláusulas de risco"), quando o agente Contratual a aplica, então termo ausente vira ⚠️ atenção ("verificar redação equivalente"), nunca ⛔ automático, e o resultado entra no relatório com a lista e a versão usadas.


## Alteração autorizada posterior à leitura inicial

RF4 teve sua descrição antes vazia preenchida com oito critérios derivados. A leitura inicial acima permanece como registro do baseline. Conteúdo e verificação da alteração: `TRELLO_ALTERACOES.json`. Nenhum cartão foi marcado como concluído.

A decisão Q-166 também foi acrescentada ao RF4 e relida em 11/10/2026: administração exige concessão explícita para SIGILOSO. Histórico exato em `TRELLO_ALTERACOES.json`. O cartão permanece parcial.
