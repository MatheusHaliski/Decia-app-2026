# Validação das melhorias — DECIA

Data: 11/10/2026. Referência inicial: `1932b73`. Este documento acompanha alterações posteriores à auditoria; não modifica as notas do cenário inicial.

## Resultado confirmado

**Última verificação: 576 testes Java, zero falhas/erros/skips em 13 módulos; 346 testes frontend em 35 arquivos; 28 cenários de navegador. Build de produção, lint, tipagem, tradução e verificações estáticas passaram. A tarefa manual também passou com login e banco reais, antes e depois de reiniciar a API.**

- Ambiente: dependências Node e Java instaladas, JDK 21 e Maven verificados por checksum, MySQL 8.4 saudável, API com `/actuator/health` em `UP`, chaves JWT de desenvolvimento carregadas. Configuração reutilizável salva como rascunho do ambiente; publicação ainda depende de salvar/publicar nas configurações da plataforma.
- Trello: leitura autenticada de 203 cartões; 48 RF ativos reconciliados. Cartões arquivados não foram tratados como requisitos novos. Nenhum RF foi marcado como integralmente concluído.
- Segurança de autenticação: corrigido o binding do construtor das propriedades JWT; dois testes de regressão. Os quatro formulários de autenticação agora usam POST mesmo antes da hidratação, evitando senha/código na URL. Quatro testes Playwright com JavaScript desativado passaram.
- Antes da nova API de tarefas: verificação completa Java com 549 testes, sem falhas/erros/skips, nos 13 módulos; lint, tipagem e build de produção aprovados; 24 testes de navegador aprovados.
- Primeira etapa da interface de tarefas: 33 arquivos Vitest, 340 testes aprovados; lint e tipagem aprovados; verificação de tradução com 1464 chaves em português, inglês e espanhol, sem erros/avisos.
- Casos de uso de tarefas: nove testes aprovados para propriedade derivada da sessão, privacidade entre usuários, restrição de departamento, classificação de acesso, proveniência de IA, transições, justificativa de reabertura, bloqueio e paginação. Gates de cobertura e análise estática dos módulos envolvidos aprovados.

## Núcleo de tarefas validado

A verificação completa Java passou com **562 testes**, sem falhas/erros/skips, nos 13 módulos. Os dois testes novos de API e os dois testes MySQL passaram. O contrato OpenAPI foi regenerado e a tipagem do frontend passou. O build de produção foi restaurado com a API local em 8080; frontend `/login` e disponibilidade de username respondem 200, API `/api/tasks` sem sessão responde 401, health em UP.

Na suíte de navegador, 25 de 26 cenários passaram na primeira execução; o restante falhou por seletor ambíguo com o anunciador de rota do Next. O seletor foi corrigido e os dois cenários novos passaram na repetição direcionada. Não houve alteração da implementação para enfraquecer o comportamento exigido.

A descrição antes vazia do RF4 foi preenchida no Trello com oito critérios derivados. A alteração foi relida e conferida; detalhes em `TRELLO_ALTERACOES.json` e `RF4_ACEITE.md`. Não houve movimentação para conclusão.

## Histórico e restauração validados

A etapa de revisões cifradas e imutáveis passou na verificação completa Java: **569 testes, zero falhas/erros/skips**, nos 13 módulos. Inclui consulta privada, restauração justificada, proteção contra revisão de outra tarefa, impossibilidade de sobrescrever registro imutável e rollback integral quando a gravação do histórico falha. A integração HTTP verifica que publicar o conteúdo atual não expõe revisões privadas anteriores. No frontend passaram 342 testes e todos os 27 cenários de navegador desta etapa.

## Isolamento empresarial e sigilo

Foi reproduzida uma falha: mudar a empresa do autor fazia a tarefa empresarial ser visível na empresa nova. A V46 cria uma âncora empresarial imutável por tarefa; leitura e restauração usam esse escopo persistido. Registros antigos sem âncora permanecem fechados a terceiros, sem inferir empresa retrospectivamente. A validação direcionada passou com 86 testes, incluindo seis testes de persistência MySQL e 15 do serviço. A regressão verifica a troca de empresa, manutenção do acesso na instituição original e recusa de reatribuição da âncora.

Q-166 foi resolvida pelo usuário: proprietário e colaboradores autorizados podem acessar SIGILOSO; administração exige concessão explícita. A política retira o acesso automático de ADMIN. Participação DACI registrada é autorização explícita para decisões. Arquivos RESTRICTED não distinguem RESTRITO de SIGILOSO: até existir concessão por arquivo, somente o dono os lê. Essa restrição conservadora também passou nos testes de serviço de mídia. A suíte completa com sigilo, teste HTTP para administrador e proteção de publicação após troca de empresa passou: **576 testes, zero falhas/erros/skips, 13 módulos**. A edição/publicação EMPRESA exige vínculo atual com a empresa da âncora; a recusa mantém o conteúdo privado e não grava nova revisão. A regressão falhou antes da proteção e passou com o serviço e MySQL.

## Conta exibida na interface

O painel consulta `/api/me` na entrada e quando a sessão muda. Dados reais prevalecem sobre o perfil ADMIN salvo no navegador; não há preenchimento fictício de empresa ou saldo. Simulação só é permitida com `NEXT_PUBLIC_DEMO_MODE=true`, ativado explicitamente nos testes do laboratório. Quatro regressões do provider e a suíte completa do frontend passaram: **346 testes em 35 arquivos**. Lint e tipagem passaram. Todos os **28 cenários de navegador** passaram, incluindo login e conta real interceptados. O build de produção para API local em 8080 e modo de demonstração desativado também passou.

A tarefa manual também foi exercitada no navegador com API, login JWT RS256, BFF e MySQL reais, em 390×844: criação, recarga, edição e restauração passaram; três revisões, nenhuma contendo texto legível em claro no banco. A conta de teste foi verificada por fixture no banco, portanto o teste não comprova envio de e-mail. Após reiniciar a API e autenticar novamente, conteúdo e três revisões permaneceram legíveis, sem overflow no celular. Sessões em memória do perfil de desenvolvimento não são prometidas como persistentes; o teste usou nova autenticação. Evidências sem credenciais: `TAREFA_REAL_BEFORE.json`, `TAREFA_REAL_AFTER.json` e `VALIDACAO_AUTOMATIZADA.json`. As tarefas geradas pela fixture foram removidas e sua conta fictícia foi inativada; a trilha de auditoria foi preservada e as credenciais temporárias, descartadas.

Os testes de navegador da suíte padrão interceptam a API para verificar a interface; os testes Java de integração verificam o banco e a autorização reais. A suíte interceptada não equivale ao teste separado com autenticação real; nenhum deles comprova SMTP, upload ou IA.

## Limites do aceite

RF4, RF8, RF12 e RF41 permanecem parciais: esta entrega cobre o núcleo manual persistente, sem concluir upload, OCR, prazos legais, todos os tipos de editor, IA ou a parte de projetos. RF1 e RF2 também permanecem parciais quanto aos demais critérios do board. As jornadas DECIA e sociais de demonstração continuam explicitamente separadas dos dados reais.

A nota 10 exige cumprir e comprovar todos os critérios da auditoria e todos os CAs dos 48 RF. Entidades, telas de demonstração e testes de regras isolados não bastam para declarar conclusão.
