# Padrão plástico WS — evolução da identidade visual

Solicitação do usuário: todos os ícones devem seguir a forma e o material plástico do logo; inserir o logo completo na topbar.

Implementado no catálogo central: 17 glifos e 9 mojis, com aro grafite, malha laranja, nós coloridos, disco creme e símbolo central com gradientes de relevo. Navegação, botões, formulários, cabeçalhos e estados usam a variante plástica por padrão. O alto contraste mantém a variante monocromática. O tamanho mínimo da variante plástica é 24 px; tamanhos maiores preservam mais detalhe.

O logo original completo está na topbar com caixa reservada de 48 × 48 px. A otimização WebP foi habilitada apenas para esse arquivo local, sem permitir origens externas. Não se altera o arquivo original fornecido.

IDs dos gradientes são únicos por instância React: vários ícones iguais na mesma tela não interferem entre si. Corrigido também o escape de `>` nos rótulos SVG de reação, que antes podia introduzir texto estranho no sprite.

Evidências:

- [Catálogo redesenhado](visual-ws/icones-plasticos.png).
- [Topbar em celular](visual-ws/topbar-claro-390.png) e [desktop](visual-ws/topbar-claro-1440.png).
- [Verificação dos quatro temas em duas larguras](visual-ws/validacao-visual.json): sem overflow horizontal e sem erros de JavaScript.
- 348 testes de frontend passaram após o redesenho; dois testes adicionais de compartilhamento são registrados na validação funcional posterior.
- Lint e build de produção passaram após o redesenho. As capturas usam um cookie simulado e renovação interceptada; são provas de desenho e responsividade, não de autenticação real.

O gerador permanece como fonte de verdade em `docs/design-system/glyphs/gerar.mjs`; `scripts/glyphs/gerar-sprite.mjs` atualiza o catálogo usado pelo aplicativo. O relatório inicial de auditoria continua sendo a linha de base; esta evolução não significa que os 48 RF ou as demais dimensões já estejam concluídos.

Atualização em 12/10/2026: o saldo DP fica fora da barra compacta do celular, o nome textual da marca aparece a partir de desktop e a busca pode encolher no tablet. [Verificação de reflow](visual-ws/reflow-320.json) confirmou larguras de 320, 390, 820 e 1440 px sem rolagem horizontal. [Topbar a 320 px](visual-ws/topbar-corrigida-320.png). O logo é servido como WebP otimizado (amostra de 96 px: 1.938 bytes), mantendo o arquivo original de 1,7 MiB. A suíte completa de 28 testes Playwright passou depois dessa correção.
