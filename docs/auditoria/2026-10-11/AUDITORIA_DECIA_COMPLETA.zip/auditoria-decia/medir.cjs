const { chromium } = require('/workspace/Decia-app-2026/node_modules/@playwright/test');
const fs=require('fs');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const results=[];
 const routes=['/login','/register','/mural','/search','/tasks','/decia','/decia?tab=decisoes','/decia/decisoes/d-arquitetura','/decia?tab=sessoes','/decia?tab=revisoes','/settings','/messages'];
 for(const [name,width,height] of [['celular',390,844],['tablet',820,1180],['desktop',1440,900]]){
  const context=await browser.newContext({viewport:{width,height},locale:'pt-BR',isMobile:name==='celular',hasTouch:name==='celular'});
  await context.addCookies([{name:'ws_rt_h',value:'1',domain:'localhost',path:'/'},{name:'ws_rt',value:'e2e-sessao-simulada',domain:'localhost',path:'/bff/auth'}]);
  for(let i=0;i<routes.length;i++){
   const page=await context.newPage(); const errors=[],responses=[];
   page.on('pageerror',e=>errors.push(e.message)); page.on('response',r=>{if(r.status()>=400)responses.push({url:new URL(r.url()).pathname,status:r.status()});});
   await page.addInitScript(()=>{
    window.__audit={cls:0,lcp:0,longTasks:0};
    new PerformanceObserver(l=>{for(const e of l.getEntries())if(!e.hadRecentInput)window.__audit.cls+=e.value;}).observe({type:'layout-shift',buffered:true});
    new PerformanceObserver(l=>{for(const e of l.getEntries())window.__audit.lcp=e.startTime;}).observe({type:'largest-contentful-paint',buffered:true});
    new PerformanceObserver(l=>{for(const e of l.getEntries())window.__audit.longTasks+=e.duration;}).observe({type:'longtask',buffered:true});
   });
   const res=await page.goto('http://localhost:3000'+routes[i]); await page.waitForTimeout(1200);
   const metrics=await page.evaluate(()=>{
    const vis=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(e).visibility!=='hidden';};
    const text=[...document.querySelectorAll('body *')].filter(e=>vis(e)&&[...e.childNodes].some(n=>n.nodeType===3&&n.textContent.trim()));
    const controls=[...document.querySelectorAll('button,a,input,select,textarea,[role="button"]')].filter(vis);
    const unnamed=controls.filter(e=>!(e.getAttribute('aria-label')||e.getAttribute('aria-labelledby')||e.textContent.trim()||e.getAttribute('title')||e.labels?.length||e.querySelector('img[alt]')));
    return {...window.__audit,h1:[...document.querySelectorAll('h1')].map(e=>({text:e.textContent,size:getComputedStyle(e).fontSize})),scrollWidth:document.documentElement.scrollWidth,width:innerWidth,textNodes:text.length,smallText:text.filter(e=>parseFloat(getComputedStyle(e).fontSize)<12).length,controls:controls.length,targetsUnder44:controls.filter(e=>{const r=e.getBoundingClientRect();return r.width<44||r.height<44;}).length,unnamedControls:unnamed.map(e=>e.outerHTML.slice(0,180)),transferBytes:performance.getEntriesByType('resource').reduce((s,e)=>s+e.transferSize,0),demoText:document.body.innerText.includes('DEMO')};
   });
   const shot=`capturas/${name}-${String(i+1).padStart(2,'0')}.png`;
   await page.screenshot({path:'/workspace/auditoria-decia/'+shot,fullPage:true});
   results.push({route:routes[i],viewport:name,status:res.status(),...metrics,errors,responses,screenshot:shot}); await page.close();
  }
  await context.close();
 }
 fs.writeFileSync('/workspace/auditoria-decia/medicoes.json',JSON.stringify(results,null,2)); await browser.close(); console.log(`${results.length} visitas medidas e capturadas`);
})().catch(e=>{console.error(e);process.exit(1)});
