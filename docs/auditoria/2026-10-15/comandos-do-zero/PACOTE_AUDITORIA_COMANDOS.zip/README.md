# Work Station — auditoria de comandos

Abra docs/auditoria/2026-10-15/comandos-do-zero/README.md para as 15 etapas. Os RF51–RF72 estão em docs/produto/requisitos-studio. Scripts e fontes de pesquisa acompanham o pacote. Sem código da aplicação.
