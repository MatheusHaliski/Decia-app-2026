# IA para Drawings e DECIA — quatro níveis

Proposta de engenharia informada pelas fontes públicas abaixo. Não é evidência de implementação nem garantia de capacidades comerciais. Os scripts não consumiram créditos de IA.

| Nível | Recursos propostos | Controles de execução | Avaliação |
| --- | --- | --- | --- |
| 1 · Sugestivo | Diagnóstico de contornos abertos, duplicatas, colisões, escala e coerência visual; predição de tangente/arco; explicação por elemento. | Somente leitura; indicar regra, confiança e limitações. Não certificar ABNT por heurística. | Precisão/recall em defeitos anotados; falsos positivos; latência. |
| 2 · Assistido | Prévia fantasma; fechamento de perfil; arranjo paramétrico; transferência de estilo; roteamento de conexões com obstáculos. | Proposta versionada com diff geométrico, custo estimado e aceitar/rejeitar por escopo. | Taxa de aceitação, distância geométrica, colisões e preservação de elementos. |
| 3 · Semi-autônomo | Planejar e executar operações locais em região/camada reservada; resolver restrições e testar alternativas. | Orçamento de ferramentas, lease com fencing, validação transacional, checkpoint e rollback. Mudança de escopo exige nova revisão. | Convergência das restrições; conflitos; recuperação; invariantes preservadas. |
| 4 · Agente | Decompor objetivo em plano; gerar alternativas; executar ferramentas CAD; verificar medidas, topologia e requisitos; entregar relatório rastreável. | Sandbox, permissões mínimas, limites de custo e tempo, parada por incerteza, aprovação de publicação e alterações de escopo. | Sucesso de tarefa em benchmark; custo; qualidade da justificativa; ausência de alterações fora do escopo. |

## Contrato dos comandos

- `AI_COMPLETE/AICOMP`: escolher objeto/região/camada; fixar revisão; respeitar reservas; prévia antes de aplicar. Separar previsão algorítmica de inferência de provedor.
- `AI_GENERATE/AIGEN`: prompt + restrições → plano estruturado de operações permitidas; validar saída antes de qualquer mutação.
- `AI_AUDIT/AIAUD`: relatório de regras geométricas, tolerâncias, evidências e itens que exigem revisão profissional. Roteamento MEP requer bibliotecas e normas específicas, não apenas um LLM.
- `AI_STYLE/AISTY`: referência explícita; sugerir alterações de material/traço sem mudar permissões ou autoria.
- `AI_OPTIMIZE/AIOPT`: medir erro máximo, preservar furos, âncoras de cota e conectividade; comparar antes/depois.
- `AI_CONVERT/AICONV`: vetorizar raster/croqui com revisão de escala, contornos e incerteza; não inferir dimensões ausentes como fatos.

## Arquitetura recomendada

Pipeline: intenção → escopo autorizado → plano tipado → simulador/prévia → checagem topológica e dimensional → aprovação exigida pelo nível → patch versionado → auditoria. Conteúdo de arquivos e imagens é dado não confiável; não pode autorizar ferramentas ou alterar políticas. Ferramentas não recebem chaves nem acesso arbitrário à rede. A política SIGILOSO permanece proprietário e colaboradores explicitamente autorizados.

## Fontes consultadas

- [OpenAI — segurança em agentes](https://platform.openai.com/docs/guides/agent-builder-safety): texto_obtido; 4 termos encontrados.
- [OpenAI — avaliações de agentes](https://platform.openai.com/docs/guides/agent-evals): texto_obtido; 3 termos encontrados.
- [Microsoft — diretrizes de interação humano-IA](https://www.microsoft.com/en-us/research/publication/guidelines-for-human-ai-interaction/): texto_obtido; 2 termos encontrados.
- [SketchGraphs — restrições geométricas em CAD](https://arxiv.org/abs/2007.08506): texto_obtido; 4 termos encontrados.
- [Text2CAD — geração paramétrica por texto](https://arxiv.org/abs/2409.17106): texto_obtido; 4 termos encontrados.
- [Adobe — preenchimento generativo de formas](https://helpx.adobe.com/illustrator/using/generative-shape-fill.html): texto_obtido; 4 termos encontrados.

[Metadados e trechos literais](fontes-ia.json). Páginas indisponíveis, mecanismos de proteção e ausência de termos são registrados, sem inventar conclusões.
